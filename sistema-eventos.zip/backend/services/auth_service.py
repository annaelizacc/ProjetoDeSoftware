from werkzeug.security import check_password_hash

from backend.models.usuario import Usuario


class AuthService:
    @staticmethod
    def login(email, senha):
        usuario = Usuario.query.filter_by(email=email.strip().lower()).first()
        if not usuario:
            return None

        # O SQL novo usa hashes Werkzeug (prefixo "pbkdf2:" ou "scrypt:").
        # O banco de demonstração ainda tem senhas em texto puro, então
        # detectamos o formato antes de comparar em vez de depender de
        # uma exceção que o Werkzeug não levanta mais nessas versões.
        hash_valido = usuario.senha.startswith(("pbkdf2:", "scrypt:"))
        if hash_valido:
            senha_valida = check_password_hash(usuario.senha, senha)
        else:
            senha_valida = usuario.senha == senha
        return usuario if senha_valida else None