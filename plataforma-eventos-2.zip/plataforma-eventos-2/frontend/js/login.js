// Alterna entre mostrar e esconder a senha digitada
const btnAlternarSenha = document.getElementById("btn-alternar-senha");
const campoSenha = document.getElementById("senha");

btnAlternarSenha.addEventListener("click", () => {
    const visivel = campoSenha.type === "text";
    campoSenha.type = visivel ? "password" : "text";
    btnAlternarSenha.textContent = visivel ? "👁" : "🙈";
});

document.getElementById("form-login").addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const email = document.getElementById("email").value;
    const senha = campoSenha.value;
    const mensagem = document.getElementById("mensagem");
    mensagem.innerHTML = "";

    try {
        const resposta = await apiFetch("/auth/login", {
            method: "POST",
            body: JSON.stringify({ email, senha }),
        });

        mensagem.innerHTML = `Bem-vindo(a), ${resposta.usuario.nome}!`;
        setTimeout(() => (window.location.href = "index.html"), 1000);
    } catch (erro) {
        mensagem.innerHTML = erro.message;
    }
});
