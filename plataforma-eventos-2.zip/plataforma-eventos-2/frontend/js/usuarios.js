const form = document.getElementById("form-usuario");
const mensagem = document.getElementById("mensagem");
const btnCancelar = document.getElementById("btn-cancelar");

async function carregarUsuarios() {
    const container = document.getElementById("lista-usuarios");
    container.innerHTML = "Carregando...";

    try {
        const usuarios = await apiFetch("/usuarios");

        if (usuarios.length === 0) {
            container.innerHTML = "<p>Nenhum usuário cadastrado ainda.</p>";
            return;
        }

        container.innerHTML = usuarios
            .map(
                (u) => `
            <div class="card">
                <h3>${u.nome}</h3>
                <span class="tag">${u.tipo_usuario}</span>
                <p>${u.email}</p>
                <div class="acoes">
                    <button onclick="editarUsuario(${u.id_usuario})">Editar</button>
                    <button class="perigo" onclick="excluirUsuario(${u.id_usuario})">Excluir</button>
                </div>
            </div>
        `
            )
            .join("");
    } catch (erro) {
        container.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
}

form.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mensagem.innerHTML = "";

    const id = document.getElementById("id_usuario").value;
    const corpo = {
        nome: document.getElementById("nome").value,
        email: document.getElementById("email").value,
        tipo_usuario: document.getElementById("tipo_usuario").value,
    };
    const senha = document.getElementById("senha").value;
    if (senha) corpo.senha = senha;

    try {
        if (id) {
            await apiFetch(`/usuarios/${id}`, { method: "PUT", body: JSON.stringify(corpo) });
            mensagem.innerHTML = `<p class="sucesso">Usuário atualizado com sucesso!</p>`;
        } else {
            if (!senha) {
                mensagem.innerHTML = `<p class="erro">Informe uma senha para cadastrar o usuário.</p>`;
                return;
            }
            await apiFetch("/usuarios", { method: "POST", body: JSON.stringify(corpo) });
            mensagem.innerHTML = `<p class="sucesso">Usuário cadastrado com sucesso!</p>`;
        }
        limparFormulario();
        carregarUsuarios();
    } catch (erro) {
        mensagem.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
});

async function editarUsuario(id) {
    const u = await apiFetch(`/usuarios/${id}`);
    document.getElementById("id_usuario").value = u.id_usuario;
    document.getElementById("nome").value = u.nome;
    document.getElementById("email").value = u.email;
    document.getElementById("tipo_usuario").value = u.tipo_usuario;
    document.getElementById("senha").value = "";
    btnCancelar.style.display = "inline-block";
    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function excluirUsuario(id) {
    if (!confirm("Tem certeza que deseja excluir este usuário?")) return;
    try {
        await apiFetch(`/usuarios/${id}`, { method: "DELETE" });
        carregarUsuarios();
    } catch (erro) {
        alert(erro.message);
    }
}

function limparFormulario() {
    form.reset();
    document.getElementById("id_usuario").value = "";
    btnCancelar.style.display = "none";
}

btnCancelar.addEventListener("click", limparFormulario);

carregarUsuarios();
