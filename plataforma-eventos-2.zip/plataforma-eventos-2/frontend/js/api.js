// URL base da API Flask
const API_URL = "http://127.0.0.1:5000";

/**
 * Função auxiliar para centralizar as chamadas fetch à API.
 * Já trata erros e converte a resposta para JSON.
 */
async function apiFetch(caminho, opcoes = {}) {
    const resposta = await fetch(`${API_URL}${caminho}`, {
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        ...opcoes,
    });

    const dados = await resposta.json().catch(() => ({}));

    if (!resposta.ok) {
        throw new Error(dados.erro || "Erro ao comunicar com a API");
    }
    return dados;
}
