async function carregarPalestras() {
    const container = document.getElementById("lista-palestras");
    container.innerHTML = "Carregando...";

    try {
        const palestras = await apiFetch("/palestras");

        if (palestras.length === 0) {
            container.innerHTML = "<p>Nenhuma palestra cadastrada ainda.</p>";
            return;
        }

        container.innerHTML = palestras
            .map(
                (p) => `
            <div class="card">
                <h3>${p.titulo}</h3>
                <span class="tag">${p.nome_evento || "Evento não informado"}</span>
                <span class="tag">Sala: ${p.sala || "-"}</span>
                <p>${p.resumo || ""}</p>
                <p><strong>Início:</strong> ${formatarData(p.horario_inicio)} &nbsp;
                   <strong>Fim:</strong> ${formatarData(p.horario_fim)}</p>
                <a href="palestras.html?id=${p.id_palestra}">Ver detalhes e comentários</a>
            </div>
        `
            )
            .join("");
    } catch (erro) {
        container.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
}

function formatarData(valor) {
    if (!valor) return "-";
    const data = new Date(valor);
    return data.toLocaleString("pt-BR");
}

carregarPalestras();
