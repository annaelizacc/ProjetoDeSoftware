const form = document.getElementById("form-palestra");
const mensagem = document.getElementById("mensagem");
const btnCancelar = document.getElementById("btn-cancelar");
const selectEvento = document.getElementById("id_evento");

async function carregarEventosNoSelect() {
    const eventos = await apiFetch("/eventos");
    selectEvento.innerHTML = eventos
        .map((e) => `<option value="${e.id_evento}">${e.nome}</option>`)
        .join("");
}

async function carregarPalestras() {
    const container = document.getElementById("lista-palestras");
    container.innerHTML = "Carregando...";

    try {
        const palestras = await apiFetch("/palestras");

        if (palestras.length === 0) {
            container.innerHTML = "<p>Nenhuma palestra cadastrada ainda.</p>";
            return;
        }

        container.innerHTML = palestras
            .map(
                (p) => `
            <div class="card">
                <h3>${p.titulo}</h3>
                <span class="tag">${p.nome_evento || ""}</span>
                <span class="tag">Sala: ${p.sala || "-"}</span>
                <p>${p.resumo || ""}</p>
                <div class="acoes">
                    <button onclick="editarPalestra(${p.id_palestra})">Editar</button>
                    <button class="perigo" onclick="excluirPalestra(${p.id_palestra})">Excluir</button>
                    <button class="secundario" onclick="verComentarios(${p.id_palestra}, '${p.titulo.replace(/'/g, "")}')">Ver comentários</button>
                </div>
            </div>
        `
            )
            .join("");
    } catch (erro) {
        container.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
}

form.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mensagem.innerHTML = "";

    const id = document.getElementById("id_palestra").value;
    const corpo = {
        id_evento: parseInt(selectEvento.value),
        titulo: document.getElementById("titulo").value,
        resumo: document.getElementById("resumo").value,
        tema: document.getElementById("tema").value,
        sala: document.getElementById("sala").value,
        horario_inicio: document.getElementById("horario_inicio").value || null,
        horario_fim: document.getElementById("horario_fim").value || null,
    };

    try {
        if (id) {
            await apiFetch(`/palestras/${id}`, { method: "PUT", body: JSON.stringify(corpo) });
            mensagem.innerHTML = `<p class="sucesso">Palestra atualizada com sucesso!</p>`;
        } else {
            await apiFetch("/palestras", { method: "POST", body: JSON.stringify(corpo) });
            mensagem.innerHTML = `<p class="sucesso">Palestra cadastrada com sucesso!</p>`;
        }
        limparFormulario();
        carregarPalestras();
    } catch (erro) {
        mensagem.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
});

async function editarPalestra(id) {
    const p = await apiFetch(`/palestras/${id}`);
    document.getElementById("id_palestra").value = p.id_palestra;
    selectEvento.value = p.id_evento;
    document.getElementById("titulo").value = p.titulo;
    document.getElementById("resumo").value = p.resumo || "";
    document.getElementById("tema").value = p.tema || "";
    document.getElementById("sala").value = p.sala || "";
    document.getElementById("horario_inicio").value = p.horario_inicio ? p.horario_inicio.slice(0, 16) : "";
    document.getElementById("horario_fim").value = p.horario_fim ? p.horario_fim.slice(0, 16) : "";
    btnCancelar.style.display = "inline-block";
    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function excluirPalestra(id) {
    if (!confirm("Tem certeza que deseja excluir esta palestra?")) return;
    try {
        await apiFetch(`/palestras/${id}`, { method: "DELETE" });
        carregarPalestras();
    } catch (erro) {
        alert(erro.message);
    }
}

function limparFormulario() {
    form.reset();
    document.getElementById("id_palestra").value = "";
    btnCancelar.style.display = "none";
}

btnCancelar.addEventListener("click", limparFormulario);

// ---------- Comentários da palestra selecionada ----------

async function verComentarios(idPalestra, titulo) {
    const container = document.getElementById("detalhe-palestra");
    container.innerHTML = `<h2>Comentários - ${titulo}</h2><p>Carregando...</p>`;

    const comentarios = await apiFetch(`/comentarios?id_palestra=${idPalestra}`);

    container.innerHTML = `
        <h2>Comentários - ${titulo}</h2>

        <form id="form-comentario">
            <label for="id_usuario">ID do usuário</label>
            <input type="number" id="id_usuario" required>

            <label for="texto">Comentário</label>
            <textarea id="texto" rows="2" required></textarea>

            <label for="nota">Nota (0 a 10)</label>
            <input type="number" id="nota" step="0.1" min="0" max="10">

            <button type="submit">Enviar comentário</button>
        </form>

        <div id="lista-comentarios">
            ${
                comentarios.length === 0
                    ? "<p>Nenhum comentário ainda.</p>"
                    : comentarios
                          .map(
                              (c) => `
                <div class="card">
                    <p><strong>${c.nome_usuario || "Usuário " + c.id_usuario}</strong> — nota: ${c.nota ?? "-"}</p>
                    <p>${c.texto}</p>
                    <button class="perigo" onclick="excluirComentario(${c.id_comentario}, ${idPalestra}, '${titulo.replace(/'/g, "")}')">Excluir</button>
                </div>
            `
                          )
                          .join("")
            }
        </div>
    `;

    document.getElementById("form-comentario").addEventListener("submit", async (evento) => {
        evento.preventDefault();
        const corpo = {
            id_palestra: idPalestra,
            id_usuario: parseInt(document.getElementById("id_usuario").value),
            texto: document.getElementById("texto").value,
            nota: document.getElementById("nota").value || null,
        };
        try {
            await apiFetch("/comentarios", { method: "POST", body: JSON.stringify(corpo) });
            verComentarios(idPalestra, titulo);
        } catch (erro) {
            alert(erro.message);
        }
    });
}

async function excluirComentario(idComentario, idPalestra, titulo) {
    if (!confirm("Excluir este comentário?")) return;
    await apiFetch(`/comentarios/${idComentario}`, { method: "DELETE" });
    verComentarios(idPalestra, titulo);
}

carregarEventosNoSelect().then(carregarPalestras);
