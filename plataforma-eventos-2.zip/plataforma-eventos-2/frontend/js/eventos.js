const form = document.getElementById("form-evento");
const mensagem = document.getElementById("mensagem");
const btnCancelar = document.getElementById("btn-cancelar");

async function carregarEventos() {
    const container = document.getElementById("lista-eventos");
    container.innerHTML = "Carregando...";

    try {
        const eventos = await apiFetch("/eventos");

        if (eventos.length === 0) {
            container.innerHTML = "<p>Nenhum evento cadastrado ainda.</p>";
            return;
        }

        container.innerHTML = eventos
            .map(
                (e) => `
            <div class="card">
                <h3>${e.nome}</h3>
                <p>${e.descricao || ""}</p>
                <p><strong>Período:</strong> ${e.data_inicio} até ${e.data_fim}</p>
                <p><strong>Local:</strong> ${e.local || "-"}</p>
                <div class="acoes">
                    <button onclick="editarEvento(${e.id_evento})">Editar</button>
                    <button class="perigo" onclick="excluirEvento(${e.id_evento})">Excluir</button>
                </div>
            </div>
        `
            )
            .join("");
    } catch (erro) {
        container.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
}

form.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mensagem.innerHTML = "";

    const id = document.getElementById("id_evento").value;
    const corpo = {
        nome: document.getElementById("nome").value,
        descricao: document.getElementById("descricao").value,
        data_inicio: document.getElementById("data_inicio").value,
        data_fim: document.getElementById("data_fim").value,
        local: document.getElementById("local").value,
    };

    try {
        if (id) {
            await apiFetch(`/eventos/${id}`, { method: "PUT", body: JSON.stringify(corpo) });
            mensagem.innerHTML = `<p class="sucesso">Evento atualizado com sucesso!</p>`;
        } else {
            await apiFetch("/eventos", { method: "POST", body: JSON.stringify(corpo) });
            mensagem.innerHTML = `<p class="sucesso">Evento cadastrado com sucesso!</p>`;
        }
        limparFormulario();
        carregarEventos();
    } catch (erro) {
        mensagem.innerHTML = `<p class="erro">${erro.message}</p>`;
    }
});

async function editarEvento(id) {
    const evento = await apiFetch(`/eventos/${id}`);
    document.getElementById("id_evento").value = evento.id_evento;
    document.getElementById("nome").value = evento.nome;
    document.getElementById("descricao").value = evento.descricao || "";
    document.getElementById("data_inicio").value = evento.data_inicio;
    document.getElementById("data_fim").value = evento.data_fim;
    document.getElementById("local").value = evento.local || "";
    btnCancelar.style.display = "inline-block";
    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function excluirEvento(id) {
    if (!confirm("Tem certeza que deseja excluir este evento?")) return;
    try {
        await apiFetch(`/eventos/${id}`, { method: "DELETE" });
        carregarEventos();
    } catch (erro) {
        alert(erro.message);
    }
}

function limparFormulario() {
    form.reset();
    document.getElementById("id_evento").value = "";
    btnCancelar.style.display = "none";
}

btnCancelar.addEventListener("click", limparFormulario);

carregarEventos();
