# Plataforma de Eventos — Flask + SQLAlchemy + MySQL

Projeto escolar de CRUD completo, seguindo a arquitetura em camadas
sugerida pelo professor:

```
Frontend  →  Controller  →  Service  →  Repository  →  Model  →  Banco de Dados
```

## Estrutura de pastas

```
plataforma-eventos/
├── frontend/                  # HTML + CSS + JS puro, consome a API via fetch
│   ├── css/style.css
│   ├── js/
│   │   ├── api.js             # helper central de chamadas fetch
│   │   ├── home.js
│   │   ├── login.js
│   │   ├── eventos.js
│   │   ├── palestras.js
│   │   └── usuarios.js
│   ├── index.html             # página inicial (lista palestras)
│   ├── login.html
│   ├── eventos.html           # CRUD de Evento
│   ├── palestras.html         # CRUD de Palestra + comentários
│   └── usuarios.html          # CRUD de Usuário (cadastro)
│
└── backend/
    ├── app.py                 # ponto de entrada da API Flask
    ├── config.py              # configuração/conexão com o MySQL
    ├── extensions.py          # instância única do SQLAlchemy (db)
    ├── requirements.txt
    ├── .env.example
    ├── database/
    │   └── create_database.sql   # script para criar o banco no MySQL
    ├── models/                # 1 arquivo por entidade do diagrama (11 tabelas)
    ├── repositories/          # acesso direto ao banco (Usuario, Evento, Palestra, Comentario)
    └── services/               # regras de negócio
    └── controllers/            # rotas Flask (Blueprints)
```

> As entidades **Usuario, Evento, Palestra e Comentario** têm CRUD completo
> (repository + service + controller + tela). As demais tabelas do diagrama
> (Restaurante, Organizador, Notificacao, Participacao, Planta_baixa,
> Localizacao) já têm o **Model** pronto no banco — o mesmo padrão de
> repository/service/controller pode ser copiado para elas se o grupo
> quiser exibir mais telas no Pitch.

## Passo 1 — Criar o banco de dados no MySQL

Abra o MySQL (Workbench, DBeaver ou terminal) e rode o script:

```
backend/database/create_database.sql
```

Ele já cria o banco `sistema_eventos` e todas as tabelas.
(O Flask também consegue criar as tabelas sozinho com `db.create_all()`,
mas o script SQL é útil para mostrar no Pitch.)

## Passo 2 — Configurar e rodar o backend (API Flask)

```bash
cd backend
python -m venv .venv

# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt

# copie o arquivo de exemplo e ajuste usuário/senha do seu MySQL
cp .env.example .env

python app.py
```

A API sobe em: **http://127.0.0.1:5000**

## Passo 3 — Rodar o frontend

Em outro terminal:

```bash
cd frontend
python -m http.server 5500
```

Acesse: **http://127.0.0.1:5500**

## Rotas da API

| Método | Rota                              | Descrição                          |
|--------|------------------------------------|-------------------------------------|
| GET    | `/eventos`                         | Lista eventos                       |
| GET    | `/eventos/<id>`                    | Busca evento por id                 |
| POST   | `/eventos`                         | Cria evento                         |
| PUT    | `/eventos/<id>`                    | Atualiza evento                     |
| DELETE | `/eventos/<id>`                    | Remove evento                       |
| GET    | `/palestras`                       | Lista palestras (aceita `?id_evento=`) |
| GET    | `/palestras/<id>`                  | Busca palestra por id               |
| POST   | `/palestras`                       | Cria palestra                       |
| PUT    | `/palestras/<id>`                  | Atualiza palestra                   |
| DELETE | `/palestras/<id>`                  | Remove palestra                     |
| GET    | `/comentarios?id_palestra=<id>`    | Lista comentários de uma palestra   |
| POST   | `/comentarios`                     | Cria comentário                     |
| PUT    | `/comentarios/<id>`                | Atualiza comentário                 |
| DELETE | `/comentarios/<id>`                | Remove comentário                   |
| GET    | `/usuarios`                        | Lista usuários                      |
| GET    | `/usuarios/<id>`                   | Busca usuário por id                |
| POST   | `/usuarios`                        | Cadastra usuário                    |
| PUT    | `/usuarios/<id>`                   | Atualiza usuário                    |
| DELETE | `/usuarios/<id>`                   | Remove usuário                      |
| POST   | `/auth/login`                      | Login (e-mail + senha)              |
| POST   | `/auth/logout`                     | Logout                              |
| GET    | `/auth/me`                         | Usuário logado na sessão            |

## Sobre palestras simultâneas

De propósito, **não existe nenhuma validação que impeça duas palestras de
terem o mesmo horário**. O campo `sala` diferencia onde cada uma acontece,
mas o sistema permite cadastrar quantas palestras simultâneas o grupo quiser
— isso é testado no `services/palestra_service.py`, no comentário acima do
método `criar_palestra`.
