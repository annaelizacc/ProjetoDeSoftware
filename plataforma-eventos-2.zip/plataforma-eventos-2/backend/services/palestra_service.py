from datetime import datetime

from models.palestra import Palestra
from repositories.palestra_repository import PalestraRepository


class PalestraService:

    @staticmethod
    def listar_palestras(id_evento=None):
        if id_evento:
            palestras = PalestraRepository.listar_por_evento(id_evento)
        else:
            palestras = PalestraRepository.listar_todas()
        return [p.to_dict() for p in palestras]

    @staticmethod
    def buscar_palestra(id_palestra):
        palestra = PalestraRepository.buscar_por_id(id_palestra)
        return palestra.to_dict() if palestra else None

    @staticmethod
    def _parse_datetime(valor):
        return datetime.strptime(valor, "%Y-%m-%dT%H:%M") if valor else None

    @staticmethod
    def criar_palestra(dados):
        if not dados.get("titulo") or not dados.get("id_evento"):
            raise ValueError("titulo e id_evento são obrigatórios")

        # Propositalmente NÃO há verificação de conflito de horário/sala:
        # o projeto permite palestras simultâneas.
        palestra = Palestra(
            titulo=dados["titulo"],
            resumo=dados.get("resumo"),
            tema=dados.get("tema"),
            sala=dados.get("sala"),
            horario_inicio=PalestraService._parse_datetime(dados.get("horario_inicio")),
            horario_fim=PalestraService._parse_datetime(dados.get("horario_fim")),
            id_evento=dados["id_evento"],
        )
        PalestraRepository.criar(palestra)
        return palestra.to_dict()

    @staticmethod
    def atualizar_palestra(id_palestra, dados):
        palestra = PalestraRepository.buscar_por_id(id_palestra)
        if not palestra:
            return None

        palestra.titulo = dados.get("titulo", palestra.titulo)
        palestra.resumo = dados.get("resumo", palestra.resumo)
        palestra.tema = dados.get("tema", palestra.tema)
        palestra.sala = dados.get("sala", palestra.sala)
        if dados.get("horario_inicio"):
            palestra.horario_inicio = PalestraService._parse_datetime(dados["horario_inicio"])
        if dados.get("horario_fim"):
            palestra.horario_fim = PalestraService._parse_datetime(dados["horario_fim"])
        palestra.id_evento = dados.get("id_evento", palestra.id_evento)

        PalestraRepository.atualizar()
        return palestra.to_dict()

    @staticmethod
    def deletar_palestra(id_palestra):
        palestra = PalestraRepository.buscar_por_id(id_palestra)
        if not palestra:
            return False
        PalestraRepository.deletar(palestra)
        return True
