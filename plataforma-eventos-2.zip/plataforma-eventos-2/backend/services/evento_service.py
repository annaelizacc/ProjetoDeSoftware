from datetime import datetime

from models.evento import Evento
from repositories.evento_repository import EventoRepository


class EventoService:

    @staticmethod
    def listar_eventos():
        return [e.to_dict() for e in EventoRepository.listar_todos()]

    @staticmethod
    def buscar_evento(id_evento):
        evento = EventoRepository.buscar_por_id(id_evento)
        return evento.to_dict() if evento else None

    @staticmethod
    def criar_evento(dados):
        if not dados.get("nome") or not dados.get("data_inicio") or not dados.get("data_fim"):
            raise ValueError("nome, data_inicio e data_fim são obrigatórios")

        evento = Evento(
            nome=dados["nome"],
            descricao=dados.get("descricao"),
            data_inicio=datetime.strptime(dados["data_inicio"], "%Y-%m-%d").date(),
            data_fim=datetime.strptime(dados["data_fim"], "%Y-%m-%d").date(),
            local=dados.get("local"),
        )
        EventoRepository.criar(evento)
        return evento.to_dict()

    @staticmethod
    def atualizar_evento(id_evento, dados):
        evento = EventoRepository.buscar_por_id(id_evento)
        if not evento:
            return None

        evento.nome = dados.get("nome", evento.nome)
        evento.descricao = dados.get("descricao", evento.descricao)
        if dados.get("data_inicio"):
            evento.data_inicio = datetime.strptime(dados["data_inicio"], "%Y-%m-%d").date()
        if dados.get("data_fim"):
            evento.data_fim = datetime.strptime(dados["data_fim"], "%Y-%m-%d").date()
        evento.local = dados.get("local", evento.local)

        EventoRepository.atualizar()
        return evento.to_dict()

    @staticmethod
    def deletar_evento(id_evento):
        evento = EventoRepository.buscar_por_id(id_evento)
        if not evento:
            return False
        EventoRepository.deletar(evento)
        return True
