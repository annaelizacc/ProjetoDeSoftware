from werkzeug.security import generate_password_hash, check_password_hash

from models.usuario import Usuario
from repositories.usuario_repository import UsuarioRepository


class UsuarioService:

    @staticmethod
    def listar_usuarios():
        return [u.to_dict() for u in UsuarioRepository.listar_todos()]

    @staticmethod
    def buscar_usuario(id_usuario):
        usuario = UsuarioRepository.buscar_por_id(id_usuario)
        return usuario.to_dict() if usuario else None

    @staticmethod
    def cadastrar_usuario(dados):
        if not dados.get("nome") or not dados.get("email") or not dados.get("senha"):
            raise ValueError("nome, email e senha são obrigatórios")

        if UsuarioRepository.buscar_por_email(dados["email"]):
            raise ValueError("já existe um usuário cadastrado com este e-mail")

        usuario = Usuario(
            nome=dados["nome"],
            email=dados["email"],
            senha=generate_password_hash(dados["senha"]),
            tipo_usuario=dados.get("tipo_usuario", "participante"),
        )
        UsuarioRepository.criar(usuario)
        return usuario.to_dict()

    @staticmethod
    def atualizar_usuario(id_usuario, dados):
        usuario = UsuarioRepository.buscar_por_id(id_usuario)
        if not usuario:
            return None

        usuario.nome = dados.get("nome", usuario.nome)
        usuario.email = dados.get("email", usuario.email)
        usuario.tipo_usuario = dados.get("tipo_usuario", usuario.tipo_usuario)
        if dados.get("senha"):
            usuario.senha = generate_password_hash(dados["senha"])

        UsuarioRepository.atualizar()
        return usuario.to_dict()

    @staticmethod
    def deletar_usuario(id_usuario):
        usuario = UsuarioRepository.buscar_por_id(id_usuario)
        if not usuario:
            return False
        UsuarioRepository.deletar(usuario)
        return True

    @staticmethod
    def validar_login(email, senha):
        usuario = UsuarioRepository.buscar_por_email(email)
        if not usuario:
            return None
        if not check_password_hash(usuario.senha, senha):
            return None
        return usuario.to_dict()
