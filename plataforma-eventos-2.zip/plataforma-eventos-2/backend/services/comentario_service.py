from models.comentario import Comentario
from repositories.comentario_repository import ComentarioRepository


class ComentarioService:

    @staticmethod
    def listar_por_palestra(id_palestra):
        return [c.to_dict() for c in ComentarioRepository.listar_por_palestra(id_palestra)]

    @staticmethod
    def criar_comentario(dados):
        if not dados.get("texto") or not dados.get("id_usuario") or not dados.get("id_palestra"):
            raise ValueError("texto, id_usuario e id_palestra são obrigatórios")

        comentario = Comentario(
            texto=dados["texto"],
            nota=dados.get("nota"),
            id_usuario=dados["id_usuario"],
            id_palestra=dados["id_palestra"],
        )
        ComentarioRepository.criar(comentario)
        return comentario.to_dict()

    @staticmethod
    def atualizar_comentario(id_comentario, dados):
        comentario = ComentarioRepository.buscar_por_id(id_comentario)
        if not comentario:
            return None

        comentario.texto = dados.get("texto", comentario.texto)
        comentario.nota = dados.get("nota", comentario.nota)

        ComentarioRepository.atualizar()
        return comentario.to_dict()

    @staticmethod
    def deletar_comentario(id_comentario):
        comentario = ComentarioRepository.buscar_por_id(id_comentario)
        if not comentario:
            return False
        ComentarioRepository.deletar(comentario)
        return True
