from flask import Flask, jsonify
from flask_cors import CORS

from config import Config
from extensions import db

# Importa todos os models para o SQLAlchemy conhecer as tabelas
import models  # noqa: F401

from controllers.usuario_controller import usuario_bp
from controllers.auth_controller import auth_bp
from controllers.evento_controller import evento_bp
from controllers.palestra_controller import palestra_bp
from controllers.comentario_controller import comentario_bp


def criar_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Libera o front-end (rodando em outra porta) para consumir a API
    CORS(app, supports_credentials=True)

    db.init_app(app)

    # Registro das rotas de cada entidade
    app.register_blueprint(usuario_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(evento_bp)
    app.register_blueprint(palestra_bp)
    app.register_blueprint(comentario_bp)

    @app.route("/")
    def index():
        return jsonify({"status": "API da Plataforma de Eventos no ar"})

    return app


app = criar_app()

if __name__ == "__main__":
    with app.app_context():
        # Cria as tabelas automaticamente se ainda não existirem
        # (o banco "sistema_eventos" já deve existir no MySQL)
        db.create_all()

    app.run(debug=True, port=5000)
