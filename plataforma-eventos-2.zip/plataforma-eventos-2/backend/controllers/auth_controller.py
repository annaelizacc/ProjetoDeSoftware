from flask import Blueprint, jsonify, request, session

from services.usuario_service import UsuarioService

auth_bp = Blueprint("auth_bp", __name__, url_prefix="/auth")


@auth_bp.route("/login", methods=["POST"])
def login():
    dados = request.get_json()
    email = dados.get("email")
    senha = dados.get("senha")

    if not email or not senha:
        return jsonify({"erro": "email e senha são obrigatórios"}), 400

    usuario = UsuarioService.validar_login(email, senha)
    if not usuario:
        return jsonify({"erro": "email ou senha inválidos"}), 401

    # Estrutura simples de sessão para preparar a autenticação
    session["id_usuario"] = usuario["id_usuario"]
    session["tipo_usuario"] = usuario["tipo_usuario"]

    return jsonify({"mensagem": "login realizado com sucesso", "usuario": usuario})


@auth_bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"mensagem": "logout realizado com sucesso"})


@auth_bp.route("/me", methods=["GET"])
def usuario_logado():
    if "id_usuario" not in session:
        return jsonify({"erro": "nenhum usuário logado"}), 401
    return jsonify({
        "id_usuario": session["id_usuario"],
        "tipo_usuario": session["tipo_usuario"],
    })
