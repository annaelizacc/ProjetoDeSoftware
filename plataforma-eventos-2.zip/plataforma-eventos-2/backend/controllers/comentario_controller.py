from flask import Blueprint, jsonify, request

from services.comentario_service import ComentarioService

comentario_bp = Blueprint("comentario_bp", __name__, url_prefix="/comentarios")


@comentario_bp.route("", methods=["GET"])
def listar_comentarios():
    id_palestra = request.args.get("id_palestra", type=int)
    if not id_palestra:
        return jsonify({"erro": "informe id_palestra na query string"}), 400
    return jsonify(ComentarioService.listar_por_palestra(id_palestra))


@comentario_bp.route("", methods=["POST"])
def criar_comentario():
    try:
        comentario = ComentarioService.criar_comentario(request.get_json())
        return jsonify(comentario), 201
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400


@comentario_bp.route("/<int:id_comentario>", methods=["PUT"])
def atualizar_comentario(id_comentario):
    comentario = ComentarioService.atualizar_comentario(id_comentario, request.get_json())
    if not comentario:
        return jsonify({"erro": "comentário não encontrado"}), 404
    return jsonify(comentario)


@comentario_bp.route("/<int:id_comentario>", methods=["DELETE"])
def deletar_comentario(id_comentario):
    sucesso = ComentarioService.deletar_comentario(id_comentario)
    if not sucesso:
        return jsonify({"erro": "comentário não encontrado"}), 404
    return jsonify({"mensagem": "comentário removido com sucesso"})
