from flask import Blueprint, jsonify, request

from services.palestra_service import PalestraService

palestra_bp = Blueprint("palestra_bp", __name__, url_prefix="/palestras")


@palestra_bp.route("", methods=["GET"])
def listar_palestras():
    id_evento = request.args.get("id_evento", type=int)
    return jsonify(PalestraService.listar_palestras(id_evento))


@palestra_bp.route("/<int:id_palestra>", methods=["GET"])
def buscar_palestra(id_palestra):
    palestra = PalestraService.buscar_palestra(id_palestra)
    if not palestra:
        return jsonify({"erro": "palestra não encontrada"}), 404
    return jsonify(palestra)


@palestra_bp.route("", methods=["POST"])
def criar_palestra():
    try:
        palestra = PalestraService.criar_palestra(request.get_json())
        return jsonify(palestra), 201
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400


@palestra_bp.route("/<int:id_palestra>", methods=["PUT"])
def atualizar_palestra(id_palestra):
    palestra = PalestraService.atualizar_palestra(id_palestra, request.get_json())
    if not palestra:
        return jsonify({"erro": "palestra não encontrada"}), 404
    return jsonify(palestra)


@palestra_bp.route("/<int:id_palestra>", methods=["DELETE"])
def deletar_palestra(id_palestra):
    sucesso = PalestraService.deletar_palestra(id_palestra)
    if not sucesso:
        return jsonify({"erro": "palestra não encontrada"}), 404
    return jsonify({"mensagem": "palestra removida com sucesso"})
