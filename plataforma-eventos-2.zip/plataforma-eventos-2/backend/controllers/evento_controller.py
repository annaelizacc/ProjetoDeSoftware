from flask import Blueprint, jsonify, request

from services.evento_service import EventoService

evento_bp = Blueprint("evento_bp", __name__, url_prefix="/eventos")


@evento_bp.route("", methods=["GET"])
def listar_eventos():
    return jsonify(EventoService.listar_eventos())


@evento_bp.route("/<int:id_evento>", methods=["GET"])
def buscar_evento(id_evento):
    evento = EventoService.buscar_evento(id_evento)
    if not evento:
        return jsonify({"erro": "evento não encontrado"}), 404
    return jsonify(evento)


@evento_bp.route("", methods=["POST"])
def criar_evento():
    try:
        evento = EventoService.criar_evento(request.get_json())
        return jsonify(evento), 201
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400


@evento_bp.route("/<int:id_evento>", methods=["PUT"])
def atualizar_evento(id_evento):
    evento = EventoService.atualizar_evento(id_evento, request.get_json())
    if not evento:
        return jsonify({"erro": "evento não encontrado"}), 404
    return jsonify(evento)


@evento_bp.route("/<int:id_evento>", methods=["DELETE"])
def deletar_evento(id_evento):
    sucesso = EventoService.deletar_evento(id_evento)
    if not sucesso:
        return jsonify({"erro": "evento não encontrado"}), 404
    return jsonify({"mensagem": "evento removido com sucesso"})
