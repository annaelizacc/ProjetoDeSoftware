from flask import Blueprint, jsonify, request

from services.usuario_service import UsuarioService

usuario_bp = Blueprint("usuario_bp", __name__, url_prefix="/usuarios")


@usuario_bp.route("", methods=["GET"])
def listar_usuarios():
    return jsonify(UsuarioService.listar_usuarios())


@usuario_bp.route("/<int:id_usuario>", methods=["GET"])
def buscar_usuario(id_usuario):
    usuario = UsuarioService.buscar_usuario(id_usuario)
    if not usuario:
        return jsonify({"erro": "usuário não encontrado"}), 404
    return jsonify(usuario)


@usuario_bp.route("", methods=["POST"])
def cadastrar_usuario():
    try:
        usuario = UsuarioService.cadastrar_usuario(request.get_json())
        return jsonify(usuario), 201
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400


@usuario_bp.route("/<int:id_usuario>", methods=["PUT"])
def atualizar_usuario(id_usuario):
    usuario = UsuarioService.atualizar_usuario(id_usuario, request.get_json())
    if not usuario:
        return jsonify({"erro": "usuário não encontrado"}), 404
    return jsonify(usuario)


@usuario_bp.route("/<int:id_usuario>", methods=["DELETE"])
def deletar_usuario(id_usuario):
    sucesso = UsuarioService.deletar_usuario(id_usuario)
    if not sucesso:
        return jsonify({"erro": "usuário não encontrado"}), 404
    return jsonify({"mensagem": "usuário removido com sucesso"})
