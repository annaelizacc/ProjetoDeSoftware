# Importa todos os models para que o SQLAlchemy os registre
# antes de db.create_all() ser chamado em app.py

from models.usuario import Usuario
from models.evento import Evento
from models.palestra import Palestra
from models.comentario import Comentario
from models.organizador import Organizador
from models.restaurante import Restaurante
from models.notificacao import Notificacao
from models.participacao import Participacao
from models.planta_baixa import PlantaBaixa
from models.localizacao import Localizacao
from models.restaurante_evento import RestauranteEvento
