from extensions import db


class Localizacao(db.Model):
    __tablename__ = "localizacao"

    id_localizacao = db.Column(db.Integer, primary_key=True)
    nome_local = db.Column(db.String(150), nullable=False)
    descricao = db.Column(db.Text)
    id_evento = db.Column(
        db.Integer, db.ForeignKey("evento.id_evento"), nullable=False
    )

    def to_dict(self):
        return {
            "id_localizacao": self.id_localizacao,
            "nome_local": self.nome_local,
            "descricao": self.descricao,
            "id_evento": self.id_evento,
        }
