from extensions import db


class Palestra(db.Model):
    __tablename__ = "palestra"

    id_palestra = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(200), nullable=False)
    resumo = db.Column(db.Text)
    tema = db.Column(db.String(120))
    sala = db.Column(db.String(60))
    # Não há validação de conflito de horário: palestras podem ocorrer
    # simultaneamente em salas diferentes, conforme o projeto exige.
    horario_inicio = db.Column(db.DateTime)
    horario_fim = db.Column(db.DateTime)

    id_evento = db.Column(
        db.Integer, db.ForeignKey("evento.id_evento"), nullable=False
    )

    comentarios = db.relationship(
        "Comentario", backref="palestra", cascade="all, delete-orphan", lazy=True
    )

    def to_dict(self):
        return {
            "id_palestra": self.id_palestra,
            "titulo": self.titulo,
            "resumo": self.resumo,
            "tema": self.tema,
            "sala": self.sala,
            "horario_inicio": self.horario_inicio.isoformat() if self.horario_inicio else None,
            "horario_fim": self.horario_fim.isoformat() if self.horario_fim else None,
            "id_evento": self.id_evento,
            "nome_evento": self.evento.nome if self.evento else None,
        }
