from extensions import db


class Participacao(db.Model):
    __tablename__ = "participacao"

    id_participacao = db.Column(db.Integer, primary_key=True)
    id_usuario = db.Column(
        db.Integer, db.ForeignKey("usuario.id_usuario"), nullable=False
    )
    id_palestra = db.Column(
        db.Integer, db.ForeignKey("palestra.id_palestra"), nullable=False
    )

    __table_args__ = (
        db.UniqueConstraint("id_usuario", "id_palestra", name="uk_participacao"),
    )

    def to_dict(self):
        return {
            "id_participacao": self.id_participacao,
            "id_usuario": self.id_usuario,
            "id_palestra": self.id_palestra,
        }
