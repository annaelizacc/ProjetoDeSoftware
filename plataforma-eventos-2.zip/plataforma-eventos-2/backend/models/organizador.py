from extensions import db


class Organizador(db.Model):
    __tablename__ = "organizador"

    id_organizador = db.Column(db.Integer, primary_key=True)
    id_usuario = db.Column(
        db.Integer, db.ForeignKey("usuario.id_usuario"), nullable=False, unique=True
    )
    nivel_acesso = db.Column(db.String(50), nullable=False)

    usuario = db.relationship("Usuario")

    def to_dict(self):
        return {
            "id_organizador": self.id_organizador,
            "id_usuario": self.id_usuario,
            "nivel_acesso": self.nivel_acesso,
        }
