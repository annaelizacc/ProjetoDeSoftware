from datetime import datetime

from extensions import db


class Comentario(db.Model):
    __tablename__ = "comentario"

    id_comentario = db.Column(db.Integer, primary_key=True)
    texto = db.Column(db.Text, nullable=False)
    nota = db.Column(db.Numeric(3, 1))
    data = db.Column(db.DateTime, default=datetime.utcnow)

    id_usuario = db.Column(
        db.Integer, db.ForeignKey("usuario.id_usuario"), nullable=False
    )
    id_palestra = db.Column(
        db.Integer, db.ForeignKey("palestra.id_palestra"), nullable=False
    )

    usuario = db.relationship("Usuario")

    def to_dict(self):
        return {
            "id_comentario": self.id_comentario,
            "texto": self.texto,
            "nota": float(self.nota) if self.nota is not None else None,
            "data": self.data.isoformat() if self.data else None,
            "id_usuario": self.id_usuario,
            "nome_usuario": self.usuario.nome if self.usuario else None,
            "id_palestra": self.id_palestra,
        }
