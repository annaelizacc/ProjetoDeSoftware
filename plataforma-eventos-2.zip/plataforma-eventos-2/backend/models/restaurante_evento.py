from extensions import db


class RestauranteEvento(db.Model):
    """Tabela de junção do relacionamento N:N 'associado'
    entre Restaurante e Evento (cardinalidade (0,n)-(0,n) no diagrama)."""

    __tablename__ = "restaurante_evento"

    id_restaurante = db.Column(
        db.Integer, db.ForeignKey("restaurante.id_restaurante"), primary_key=True
    )
    id_evento = db.Column(
        db.Integer, db.ForeignKey("evento.id_evento"), primary_key=True
    )

    def to_dict(self):
        return {
            "id_restaurante": self.id_restaurante,
            "id_evento": self.id_evento,
        }
