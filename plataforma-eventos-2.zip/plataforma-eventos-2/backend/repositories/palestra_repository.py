from extensions import db
from models.palestra import Palestra


class PalestraRepository:

    @staticmethod
    def listar_todas():
        # Sem qualquer filtro de horário: palestras simultâneas são permitidas
        return Palestra.query.order_by(Palestra.horario_inicio).all()

    @staticmethod
    def listar_por_evento(id_evento):
        return Palestra.query.filter_by(id_evento=id_evento).all()

    @staticmethod
    def buscar_por_id(id_palestra):
        return Palestra.query.get(id_palestra)

    @staticmethod
    def criar(palestra):
        db.session.add(palestra)
        db.session.commit()
        return palestra

    @staticmethod
    def atualizar():
        db.session.commit()

    @staticmethod
    def deletar(palestra):
        db.session.delete(palestra)
        db.session.commit()
