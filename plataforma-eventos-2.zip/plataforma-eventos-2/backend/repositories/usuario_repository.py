from extensions import db
from models.usuario import Usuario


class UsuarioRepository:
    """Responsável apenas por conversar com o banco de dados."""

    @staticmethod
    def listar_todos():
        return Usuario.query.all()

    @staticmethod
    def buscar_por_id(id_usuario):
        return Usuario.query.get(id_usuario)

    @staticmethod
    def buscar_por_email(email):
        return Usuario.query.filter_by(email=email).first()

    @staticmethod
    def criar(usuario):
        db.session.add(usuario)
        db.session.commit()
        return usuario

    @staticmethod
    def atualizar():
        db.session.commit()

    @staticmethod
    def deletar(usuario):
        db.session.delete(usuario)
        db.session.commit()
