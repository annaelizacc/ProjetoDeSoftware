from extensions import db
from models.comentario import Comentario


class ComentarioRepository:

    @staticmethod
    def listar_por_palestra(id_palestra):
        return (
            Comentario.query.filter_by(id_palestra=id_palestra)
            .order_by(Comentario.data.desc())
            .all()
        )

    @staticmethod
    def buscar_por_id(id_comentario):
        return Comentario.query.get(id_comentario)

    @staticmethod
    def criar(comentario):
        db.session.add(comentario)
        db.session.commit()
        return comentario

    @staticmethod
    def atualizar():
        db.session.commit()

    @staticmethod
    def deletar(comentario):
        db.session.delete(comentario)
        db.session.commit()
