from extensions import db
from models.evento import Evento


class EventoRepository:

    @staticmethod
    def listar_todos():
        return Evento.query.order_by(Evento.data_inicio).all()

    @staticmethod
    def buscar_por_id(id_evento):
        return Evento.query.get(id_evento)

    @staticmethod
    def criar(evento):
        db.session.add(evento)
        db.session.commit()
        return evento

    @staticmethod
    def atualizar():
        db.session.commit()

    @staticmethod
    def deletar(evento):
        db.session.delete(evento)
        db.session.commit()
