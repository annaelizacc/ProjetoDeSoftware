from flask_sqlalchemy import SQLAlchemy

# Instância única do SQLAlchemy, importada por todos os models
db = SQLAlchemy()
