import 'package:flutter/material.dart';
import 'cores_e_menu.dart';

class TelaPalestra extends StatelessWidget {
  const TelaPalestra({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      appBar: AppBar(
        backgroundColor: corFundo,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Informações Da Palestra',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        centerTitle: true,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.notifications_none, color: Colors.white),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),

            const BannerEvento(
              titulo: 'O futuro da Inteligencia Artificial',
            ),

            const SizedBox(height: 16),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: const [
                  Text('09:30 - 10:30', style: TextStyle(color: corTextoClaro, fontSize: 15)),
                  SizedBox(width: 16),
                  Text('20 de Maio', style: TextStyle(color: corTextoClaro, fontSize: 15)),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Cartão da palestrante — fundo branco, nome numa linha só,
            // igual à imagem de referência que você mandou
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    // Avatar cinza claro com ícone de pessoa cinza escuro
                    const CircleAvatar(
                      radius: 22,
                      backgroundColor: corAvatarFundo,
                      child: Icon(Icons.person, color: corAvatarIcone, size: 26),
                    ),
                    const SizedBox(width: 12),

                    // Expanded + a linha do nome com maxLines: 1 garante
                    // que "Marina Thompson" nunca quebre em duas linhas
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Marina Thompson',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                              color: Color(0xFF1A1A1A),
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Especialista em IA e Ciência de Dados',
                            style: TextStyle(fontSize: 11.5, color: Colors.black54, height: 1.35),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),

                    // Botão "Ver perfil" azul-marinho com texto branco
                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: corBotaoPerfil,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: const Text('Ver perfil', style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Sobre a palestra',
                    style: TextStyle(color: corTextoClaro, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Lorem ipsumLorem ipsum Lorem ipsum Lorem ipsum Lorem '
                    'ipsum  Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum',
                    style: TextStyle(color: corTextoCinza, height: 1.4),
                  ),
                  SizedBox(height: 24),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                    child: _botaoContorno(
                      icone: Icons.notifications_none,
                      texto: 'Ativar Lembrete',
                      aoTocar: () {},
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _botaoContorno(
                      icone: Icons.star_border,
                      texto: 'Adicionar a agenda',
                      aoTocar: () {},
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
      bottomNavigationBar: menuInferior(selecionado: 2),
    );
  }

  Widget _botaoContorno({
    required IconData icone,
    required String texto,
    required VoidCallback aoTocar,
  }) {
    return OutlinedButton.icon(
      onPressed: aoTocar,
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 14),
        backgroundColor: corBotaoClaro.withOpacity(0.25),
        side: const BorderSide(color: corBotaoClaro),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      icon: Icon(icone, color: Colors.white, size: 18),
      label: Text(
        texto,
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.white, fontSize: 13),
      ),
    );
  }
}
