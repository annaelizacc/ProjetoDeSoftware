import 'package:flutter/material.dart';
import 'cores_e_menu.dart';
import 'tela_palestra.dart';

class TelaEvento extends StatelessWidget {
  const TelaEvento({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      appBar: AppBar(
        backgroundColor: corFundo,
        elevation: 0,
        leading: const Icon(Icons.menu, color: Colors.white),
        title: const Text('Evento', style: TextStyle(color: Colors.white)),
        centerTitle: true,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.notifications_none, color: Colors.white),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),

            // Banner com título, data e local — tudo dentro da imagem agora
            BannerEvento(
              titulo: 'Lorem ipsum',
              linhasExtras: [
                const SizedBox(height: 6),
                const Text(
                  '20 a 25 de Maio',
                  style: TextStyle(color: Color(0xFF2E3A59), fontSize: 14),
                ),
                const SizedBox(height: 8),
                Row(
                  children: const [
                    Icon(Icons.location_on_outlined, size: 15, color: Color(0xFF2E3A59)),
                    SizedBox(width: 4),
                    Text(
                      'Centro de convenções',
                      style: TextStyle(color: Color(0xFF2E3A59), fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 24),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Descrição do evento',
                    style: TextStyle(
                      color: corTextoClaro,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Lorem ipsumLorem ipsum Lorem ipsum Lorem ipsum Lorem '
                    'ipsum Lorem ipsum  Lorem ipsum Lorem ipsum Lorem ipsum '
                    'Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum',
                    style: TextStyle(color: corTextoCinza, height: 1.4),
                  ),
                  SizedBox(height: 16),
                  Divider(color: Colors.white24),
                  SizedBox(height: 16),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _botaoBranco(
                icone: Icons.map_outlined,
                texto: 'Mapa do Local',
                aoTocar: () {},
              ),
            ),
            const SizedBox(height: 16),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _botaoBranco(
                icone: Icons.event_note_outlined,
                texto: 'Programação Geral',
                aoTocar: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TelaPalestra()),
                  );
                },
              ),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
      bottomNavigationBar: menuInferior(selecionado: 0),
    );
  }

  Widget _botaoBranco({
    required IconData icone,
    required String texto,
    required VoidCallback aoTocar,
  }) {
    return InkWell(
      onTap: aoTocar,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: corBotaoClaro,
              child: Icon(icone, color: corFundo),
            ),
            const SizedBox(width: 16),
            Text(
              texto,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: corFundo,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
