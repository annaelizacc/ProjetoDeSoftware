import 'package:flutter/material.dart';

// Aqui deixo todas as cores do app juntas, assim fica fácil de mudar depois
const corFundo = Color(0xFF2E3A59); // azul escuro do fundo
const corBotaoClaro = Color(0xFFBFE0F5); // azul clarinho dos botões
const corTextoClaro = Colors.white;
const corTextoCinza = Color(0xFFC7CCDA);

// Cores usadas especificamente no cartão da palestrante (fundo branco)
const corBotaoPerfil = Color(0xFF283A66); // azul-marinho do botão "Ver perfil"
const corAvatarFundo = Color(0xFFE8E8EA); // cinza claro do círculo do avatar
const corAvatarIcone = Color(0xFFA5A5AA); // cinza do ícone dentro do avatar

// Esse é o menu branco flutuante que aparece embaixo nas duas telas.
Widget menuInferior({int selecionado = 0}) {
  final icones = [
    Icons.home_outlined,
    Icons.calendar_today_outlined,
    Icons.badge_outlined,
    Icons.notifications_outlined,
    Icons.person_outline,
  ];

  return Container(
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
    padding: const EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(30),
      boxShadow: const [
        BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0, 4)),
      ],
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: List.generate(icones.length, (indice) {
        bool estaSelecionado = indice == selecionado;
        return Icon(
          icones[indice],
          size: 26,
          color: estaSelecionado ? corFundo : Colors.grey.shade400,
        );
      }),
    ),
  );
}

// Widget do banner (a parte de cima com a imagem e o título por cima).
// Agora usa a imagem enviada como fundo, em vez do desenho feito com ClipPath.
class BannerEvento extends StatelessWidget {
  final String titulo;
  // Lista de linhas de texto que aparecem embaixo do título (data, local, etc.)
  final List<Widget> linhasExtras;

  const BannerEvento({
    super.key,
    required this.titulo,
    this.linhasExtras = const [],
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
      ),
      // Stack empilha a imagem de fundo e o texto, um em cima do outro
      child: Stack(
        children: [
          // A imagem de fundo, esticada para preencher todo o banner
          Positioned.fill(
            child: Image.asset(
              'assets/images/banner_evento.png',
              fit: BoxFit.cover,
            ),
          ),
          // O texto por cima da imagem
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  titulo,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2E3A59),
                  ),
                ),
                ...linhasExtras,
              ],
            ),
          ),
        ],
      ),
    );
  }
}
