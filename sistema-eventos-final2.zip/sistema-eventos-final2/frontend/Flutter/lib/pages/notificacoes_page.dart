import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../widgets/app_chrome.dart';

class NotificacoesPage extends StatelessWidget {
  final int usuarioId;

  const NotificacoesPage({super.key, required this.usuarioId});

  ({Color fundo, Color badge, String rotulo, String asset}) _estilo(String? tipo) {
    switch (tipo) {
      case 'atencao':
      case 'alerta':
        return (fundo: const Color(0xfffdeecb), badge: const Color(0xffb98600), rotulo: 'Atenção', asset: 'assets/images/imgAtencao.png');
      case 'confirmacao':
        return (fundo: const Color(0xffe3f7d8), badge: const Color(0xff3f8f2a), rotulo: 'Confirmado', asset: 'assets/images/imgInfo.png');
      case 'informacao':
        return (fundo: const Color(0xffdcf0fb), badge: const Color(0xff1689d2), rotulo: 'Informação', asset: 'assets/images/imgInfo.png');
      case 'lembrete':
      default:
        return (fundo: const Color(0xffdcecfb), badge: const Color(0xff0d3f73), rotulo: 'Lembrete', asset: 'assets/images/imgLembrete.png');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(titulo: 'Avisos'),
      backgroundColor: const Color(0xffeef1f5),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.notificacoes(usuarioId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final lista = snapshot.data ?? [];
          if (lista.isEmpty) return const Center(child: Text('Você não possui notificações.'));
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: lista.length,
            separatorBuilder: (_, __) => const SizedBox(height: 14),
            itemBuilder: (context, index) {
              final item = lista[index];
              final estilo = _estilo(item['tipo_notificacao']);
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: estilo.fundo,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                      padding: const EdgeInsets.all(7),
                      child: Image.asset(estilo.asset, fit: BoxFit.contain),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: estilo.badge, borderRadius: BorderRadius.circular(6)),
                            child: Text(
                              estilo.rotulo.toUpperCase(),
                              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(item['mensagem'] ?? '', style: const TextStyle(fontSize: 13, color: Color(0xff2b3a4a))),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
