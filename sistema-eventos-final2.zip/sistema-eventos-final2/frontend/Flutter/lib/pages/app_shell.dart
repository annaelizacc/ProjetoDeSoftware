import 'package:flutter/material.dart';

import '../widgets/app_chrome.dart';
import 'agenda_page.dart';
import 'favoritos_page.dart';
import 'home_page.dart';
import 'notificacoes_page.dart';

class AppShell extends StatefulWidget {
  final int usuarioId;
  final String nomeUsuario;

  const AppShell({
    super.key,
    required this.usuarioId,
    required this.nomeUsuario,
  });

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int aba = 0;

  @override
  Widget build(BuildContext context) {
    final telas = [
      HomePage(usuarioId: widget.usuarioId, nomeUsuario: widget.nomeUsuario),
      AgendaPage(usuarioId: widget.usuarioId),
      FavoritosPage(usuarioId: widget.usuarioId),
      NotificacoesPage(usuarioId: widget.usuarioId),
    ];
    return Scaffold(
      backgroundColor: const Color(0xffeef1f5),
      body: telas[aba],
      bottomNavigationBar: AppBottomBar(
        indiceSelecionado: aba,
        aoSelecionar: (index) => setState(() => aba = index),
      ),
    );
  }
}
