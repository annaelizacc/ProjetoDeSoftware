import 'package:flutter/material.dart';

import '../services/api_service.dart';
import 'app_shell.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(text: 'ana.silva@email.com');
  final senha = TextEditingController(text: 'hash123');
  bool carregando = false;

  Future<void> entrar() async {
    setState(() => carregando = true);
    try {
      final usuario = await ApiService.login(email.text, senha.text);
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => AppShell(
            usuarioId: usuario['id_usuario'],
            nomeUsuario: usuario['nome'],
          ),
        ),
      );
    } catch (erro) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(erro.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffa3d3f0),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Positioned.fill(
            child: Image.asset('assets/images/rastro.png', fit: BoxFit.cover),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Card(
              color: const Color(0xff195892).withOpacity(.92),
              elevation: 10,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              child: Padding(
                padding: const EdgeInsets.all(26),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'FLUXO',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 30),
                    const Text('Entrar', style: TextStyle(color: Colors.white, fontSize: 25)),
                    const SizedBox(height: 20),
                    TextField(
                      controller: email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: _decoracao('Email', Icons.email_outlined),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: senha,
                      obscureText: true,
                      decoration: _decoracao('Senha', Icons.lock_outline),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Fale com a organização do evento para redefinir sua senha.')),
                        ),
                        child: const Text('Esqueceu a senha?', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    FilledButton(
                      onPressed: carregando ? null : entrar,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xff062b52),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: carregando
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(color: Colors.white),
                            )
                          : const Text('Entrar'),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'ou continue com',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _iconeSocial('assets/images/googleIcon.png'),
                        const SizedBox(width: 14),
                        _iconeSocial('assets/images/gitIcon.png'),
                        const SizedBox(width: 14),
                        _iconeSocial('assets/images/faceIcon.png'),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'Use os dados de Ana Silva do banco oficial.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
        ],
      ),
    );
  }


  Widget _iconeSocial(String asset) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Image.asset(asset),
      ),
    );
  }

  InputDecoration _decoracao(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
    );
  }

  @override
  void dispose() {
    email.dispose();
    senha.dispose();
    super.dispose();
  }
}