import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';
import '../widgets/app_chrome.dart';

class PalestraDetailsPage extends StatefulWidget {
  final int usuarioId;
  final int palestraId;

  const PalestraDetailsPage({super.key, required this.usuarioId, required this.palestraId});

  @override
  State<PalestraDetailsPage> createState() => _PalestraDetailsPageState();
}

class _PalestraDetailsPageState extends State<PalestraDetailsPage> {
  late Future<Palestra> futuro;

  @override
  void initState() {
    super.initState();
    futuro = carregar();
  }

  Future<Palestra> carregar() async => Palestra.fromJson(await ApiService.palestra(widget.palestraId, widget.usuarioId));

  Future<void> executar(Future<void> Function() acao) async {
    try {
      await acao();
      if (mounted) setState(() => futuro = carregar());
    } catch (erro) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(erro.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(titulo: 'Informações da Palestra'),
      backgroundColor: const Color(0xffeef1f5),
      body: FutureBuilder<Palestra>(
        future: futuro,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final p = snapshot.data!;
          return ListView(
            padding: EdgeInsets.zero,
            children: [
              Stack(
                fit: StackFit.passthrough,
                children: [
                  Container(
                    height: 170,
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                    decoration: const BoxDecoration(color: Color(0xffa3d3f0)),
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: Image.asset('assets/images/rastro.png', fit: BoxFit.cover),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Text(
                            p.titulo,
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xff0d2c47)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.horario, style: const TextStyle(fontSize: 13, color: Colors.black54)),
                    const SizedBox(height: 16),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      Chip(label: Text(p.tema ?? 'Sem tema')),
                      Chip(label: Text(p.sala ?? 'Sala a definir')),
                    ]),
                    const SizedBox(height: 20),
                    const Text('Sobre a palestra', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xff2b3a4a))),
                    const SizedBox(height: 8),
                    Text(p.resumo ?? 'Resumo não informado.', style: const TextStyle(fontSize: 14, height: 1.5, color: Color(0xff445064))),
                    const SizedBox(height: 20),
                    Card(
                      color: p.vagas > 0 ? const Color(0xffe4f5ff) : const Color(0xffffe9e9),
                      child: ListTile(
                        leading: Icon(p.vagas > 0 ? Icons.people_alt_outlined : Icons.block),
                        title: Text(p.vagas > 0 ? '${p.vagas} vagas disponíveis' : 'Palestra lotada'),
                        subtitle: Text('Capacidade total: ${p.total}'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: p.inscrito
                          ? () => executar(() => ApiService.cancelarInscricao(widget.usuarioId, p.id))
                          : p.vagas > 0
                              ? () => executar(() => ApiService.inscrever(widget.usuarioId, p.id))
                              : null,
                      icon: Icon(p.inscrito ? Icons.event_busy : Icons.event_available),
                      label: Text(p.inscrito ? 'Cancelar inscrição' : 'Inscrever-se'),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xff0d3f73),
                              side: const BorderSide(color: Color(0xffa3d3f0)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            onPressed: () => executar(() => ApiService.alterarLembrete(widget.usuarioId, p.id, !p.lembreteAtivo)),
                            icon: Icon(p.lembreteAtivo ? Icons.notifications_active : Icons.notifications_none),
                            label: Text(p.lembreteAtivo ? 'Lembrete ativo' : 'Ativar lembrete'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xff0d3f73),
                              side: const BorderSide(color: Color(0xffa3d3f0)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            onPressed: () => executar(() => ApiService.alterarFavorito(widget.usuarioId, p.id, !p.favorita)),
                            icon: Icon(p.favorita ? Icons.star : Icons.star_border),
                            label: Text(p.favorita ? 'Favoritada' : 'Adicionar à agenda'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
