import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';
import '../widgets/app_chrome.dart';
import 'palestra_details_page.dart';

class FavoritosPage extends StatefulWidget {
  final int usuarioId;

  const FavoritosPage({super.key, required this.usuarioId});

  @override
  State<FavoritosPage> createState() => _FavoritosPageState();
}

class _FavoritosPageState extends State<FavoritosPage> with SingleTickerProviderStateMixin {
  late Future<List<dynamic>> futuro;
  late final TabController abas;

  static const _estrelas = [Color(0xff2f6bd6), Color(0xff2ea86b), Color(0xffd6493f)];

  @override
  void initState() {
    super.initState();
    futuro = ApiService.favoritos(widget.usuarioId);
    abas = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    abas.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(titulo: 'Meus Favoritos'),
      backgroundColor: const Color(0xffeef1f5),
      body: Column(
        children: [
          TabBar(
            controller: abas,
            labelColor: const Color(0xff0d3f73),
            unselectedLabelColor: Colors.black54,
            indicatorColor: const Color(0xff0d3f73),
            tabs: const [Tab(text: 'Palestras'), Tab(text: 'Palestrantes')],
          ),
          Expanded(
            child: TabBarView(
              controller: abas,
              children: [
                FutureBuilder<List<dynamic>>(
                  future: futuro,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                    if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
                    final lista = snapshot.data ?? [];
                    if (lista.isEmpty) return const Center(child: Text('Nenhuma palestra favoritada.'));
                    return ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: lista.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final p = Palestra.fromJson(Map<String, dynamic>.from(lista[index]['palestra']));
                        final cor = _estrelas[index % _estrelas.length];
                        return InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PalestraDetailsPage(usuarioId: widget.usuarioId, palestraId: p.id))),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 6, offset: const Offset(0, 2))],
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 46,
                                  height: 46,
                                  decoration: BoxDecoration(color: const Color(0xffeef1f5), borderRadius: BorderRadius.circular(10)),
                                  child: const Icon(Icons.image_outlined, color: Colors.black38),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(p.titulo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                      const SizedBox(height: 3),
                                      Text('${p.horario} • ${p.sala ?? ''}', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                                    ],
                                  ),
                                ),
                                Icon(Icons.star, color: cor),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
                const Center(child: Text('Nenhum palestrante favoritado.')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
