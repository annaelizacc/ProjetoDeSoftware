import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';
import '../widgets/app_chrome.dart';
import 'palestra_details_page.dart';

class ProgramacaoPage extends StatefulWidget {
  final int eventoId;
  final int usuarioId;
  final String nomeEvento;

  const ProgramacaoPage({super.key, required this.eventoId, required this.usuarioId, required this.nomeEvento});

  @override
  State<ProgramacaoPage> createState() => _ProgramacaoPageState();
}

class _ProgramacaoPageState extends State<ProgramacaoPage> {
  final busca = TextEditingController();
  late Future<List<dynamic>> futuro;

  static const _cores = [
    Color(0xfffdecb0),
    Color(0xfff8cfb3),
    Color(0xffc8f0c2),
    Color(0xffc0e3f7),
  ];

  @override
  void initState() {
    super.initState();
    futuro = ApiService.programacao(widget.eventoId);
  }

  void pesquisar() => setState(() => futuro = ApiService.programacao(widget.eventoId, tema: busca.text));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppTopBar(titulo: widget.nomeEvento),
      backgroundColor: const Color(0xffeef1f5),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: busca,
              onSubmitted: (_) => pesquisar(),
              decoration: InputDecoration(
                hintText: 'Pesquisar por tema',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(onPressed: pesquisar, icon: const Icon(Icons.arrow_forward)),
                filled: true,
                fillColor: const Color(0xffb9dff2),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 14),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Principais palestras', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xff2b3a4a))),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: FutureBuilder<List<dynamic>>(
                future: futuro,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                  if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
                  final lista = snapshot.data ?? [];
                  if (lista.isEmpty) return const Center(child: Text('Nenhuma palestra encontrada.'));
                  return ListView.builder(
                    itemCount: lista.length,
                    itemBuilder: (_, index) {
                      final palestra = Palestra.fromJson(Map<String, dynamic>.from(lista[index]));
                      final cor = _cores[index % _cores.length];
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PalestraDetailsPage(usuarioId: widget.usuarioId, palestraId: palestra.id))),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: cor, borderRadius: BorderRadius.circular(16)),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(palestra.titulo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xff2b3a4a))),
                                    const SizedBox(height: 6),
                                    Text(
                                      palestra.resumo ?? '${palestra.tema ?? 'Sem tema'} • ${palestra.sala ?? 'Sala a definir'} • ${palestra.horario}',
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 12, color: Color(0xff445064)),
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  const Icon(Icons.groups_outlined, size: 18, color: Color(0xff445064)),
                                  Text('+${palestra.vagas}', style: const TextStyle(fontSize: 11, color: Color(0xff445064))),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    busca.dispose();
    super.dispose();
  }
}
