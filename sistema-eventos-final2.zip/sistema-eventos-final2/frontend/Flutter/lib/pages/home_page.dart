import 'package:flutter/material.dart';

import '../services/api_service.dart';
import 'programacao_page.dart';

class HomePage extends StatefulWidget {
  final int usuarioId;
  final String nomeUsuario;

  const HomePage({super.key, required this.usuarioId, required this.nomeUsuario});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<dynamic>> futuroEventos;
  late Future<List<List<dynamic>>> futuroResumo;

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  void _carregar() {
    futuroEventos = ApiService.eventos();
    futuroResumo = Future.wait([
      ApiService.agenda(widget.usuarioId),
      ApiService.favoritos(widget.usuarioId),
      futuroEventos,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () async => setState(_carregar),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 26),
              decoration: const BoxDecoration(
                color: Color(0xffa3d3f0),
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(28), bottomRight: Radius.circular(28)),
              ),
              child: Row(
                children: [
                  const CircleAvatar(radius: 28, backgroundColor: Colors.white, child: Icon(Icons.person, color: Color(0xffa3d3f0), size: 32)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.nomeUsuario, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                        const SizedBox(height: 2),
                        const Text('Encontre seu próximo evento', style: TextStyle(fontSize: 12, color: Colors.white70)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Transform.translate(
              offset: const Offset(0, -18),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: FutureBuilder<List<List<dynamic>>>(
                    future: futuroResumo,
                    builder: (context, snapshot) {
                      final agenda = snapshot.data?[0].length ?? 0;
                      final favoritos = snapshot.data?[1].length ?? 0;
                      final eventos = snapshot.data?[2].length ?? 0;
                      Widget stat(String valor, String rotulo) => Column(
                            children: [
                              Text(valor, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                              Text(rotulo, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                            ],
                          );
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          stat('$agenda', 'Agenda'),
                          stat('$favoritos', 'Favoritos'),
                          stat('$eventos', 'Eventos'),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Eventos disponíveis', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xff063b6d))),
                  const SizedBox(height: 10),
                  FutureBuilder<List<dynamic>>(
                    future: futuroEventos,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
                      }
                      if (snapshot.hasError) return Text('Erro: ${snapshot.error}');
                      if (!snapshot.hasData || snapshot.data!.isEmpty) return const Text('Nenhum evento encontrado.');
                      return Column(
                        children: snapshot.data!.map((evento) {
                          return Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 6, offset: const Offset(0, 2))],
                            ),
                            child: ListTile(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              leading: const CircleAvatar(backgroundColor: Color(0xffdcecfb), child: Icon(Icons.event, color: Color(0xff0d3f73))),
                              title: Text(evento['nome'] ?? ''),
                              subtitle: Text(evento['local'] ?? 'Local não informado'),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ProgramacaoPage(
                                    eventoId: evento['id_evento'],
                                    nomeEvento: evento['nome'],
                                    usuarioId: widget.usuarioId,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
