import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';
import '../widgets/app_chrome.dart';
import 'palestra_details_page.dart';

class AgendaPage extends StatelessWidget {
  final int usuarioId;

  const AgendaPage({super.key, required this.usuarioId});

  static const _cores = [
    Color(0xff29abe2),
    Color(0xff6c4fd6),
    Color(0xffb04fd6),
    Color(0xff2ea86b),
    Color(0xffc9a227),
    Color(0xffd6493f),
  ];

  ({Color cor, String rotulo}) _status(Palestra p) {
    if (p.inscrito) return (cor: const Color(0xff2ea86b), rotulo: 'Inscrito');
    if (p.vagas <= 0) return (cor: const Color(0xffd6493f), rotulo: 'Lotado');
    return (cor: const Color(0xffc9a227), rotulo: 'Vagas');
  }

  bool _ehManha(Palestra p) {
    final data = p.inicio == null ? null : DateTime.tryParse(p.inicio!);
    return data == null || data.hour < 12;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(titulo: 'Agenda Virtual'),
      backgroundColor: const Color(0xffeef1f5),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.agenda(usuarioId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final lista = snapshot.data ?? [];
          if (lista.isEmpty) return const Center(child: Text('Você ainda não possui inscrições.'));

          final palestras = lista.map((json) => Palestra.fromJson(Map<String, dynamic>.from(json))).toList();
          final manha = palestras.where(_ehManha).toList();
          final tarde = palestras.where((p) => !_ehManha(p)).toList();

          Widget grupo(String titulo, List<Palestra> itens) {
            if (itens.isEmpty) return const SizedBox.shrink();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
                  child: Text(titulo, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xff2b3a4a))),
                ),
                ...itens.asMap().entries.map((entrada) {
                  final p = entrada.value;
                  final cor = _cores[entrada.key % _cores.length];
                  final status = _status(p);
                  return InkWell(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PalestraDetailsPage(usuarioId: usuarioId, palestraId: p.id))),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Row(
                        children: [
                          Container(width: 10, height: 10, decoration: BoxDecoration(color: cor, shape: BoxShape.circle)),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(p.titulo, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                                Text('${p.horario} • ${p.sala ?? ''}', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: status.cor.withOpacity(.15), borderRadius: BorderRadius.circular(20)),
                            child: Text(status.rotulo, style: TextStyle(color: status.cor, fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(width: 4),
                          const Icon(Icons.chevron_right, size: 18, color: Colors.black38),
                        ],
                      ),
                    ),
                  );
                }),
                const Divider(height: 1),
              ],
            );
          }

          return ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              grupo('Manhã', manha),
              grupo('Tarde', tarde),
              const SizedBox(height: 16),
            ],
          );
        },
      ),
    );
  }
}
