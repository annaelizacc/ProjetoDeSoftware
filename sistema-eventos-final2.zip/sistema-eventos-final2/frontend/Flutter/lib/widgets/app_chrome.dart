import 'package:flutter/material.dart';

/// Cabeçalho reutilizado nas telas internas do app, no mesmo estilo do
/// protótipo: fundo claro, ícone de menu, título e sino de avisos.
class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  final String titulo;
  final VoidCallback? aoTocarSino;
  final Widget? acaoExtra;

  const AppTopBar({
    super.key,
    required this.titulo,
    this.aoTocarSino,
    this.acaoExtra,
  });

  @override
  Size get preferredSize => const Size.fromHeight(60);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: const Color(0xffeef1f5),
      elevation: 0,
      leading: Builder(
        builder: (ctx) => IconButton(
          icon: const Icon(Icons.menu, color: Color(0xff33475b)),
          onPressed: Scaffold.maybeOf(ctx)?.hasDrawer == true
              ? () => Scaffold.of(ctx).openDrawer()
              : null,
        ),
      ),
      title: Text(
        titulo,
        style: const TextStyle(
          color: Color(0xff1c2b39),
          fontWeight: FontWeight.w600,
          fontSize: 18,
        ),
      ),
      actions: [
        if (acaoExtra != null) acaoExtra!,
        IconButton(
          icon: const Icon(Icons.notifications_none, color: Color(0xff33475b)),
          onPressed: aoTocarSino,
        ),
      ],
    );
  }
}

/// Barra inferior arredondada usada no protótipo, mantendo a mesma
/// navegação (Início, Agenda, Favoritos, Avisos) já existente no app.
class AppBottomBar extends StatelessWidget {
  final int indiceSelecionado;
  final ValueChanged<int> aoSelecionar;

  const AppBottomBar({
    super.key,
    required this.indiceSelecionado,
    required this.aoSelecionar,
  });

  static const _itens = [
    (Icons.home_outlined, Icons.home, 'Início'),
    (Icons.calendar_month_outlined, Icons.calendar_month, 'Agenda'),
    (Icons.star_border, Icons.star, 'Favoritos'),
    (Icons.notifications_none, Icons.notifications, 'Avisos'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Container(
          height: 58,
          decoration: BoxDecoration(
            color: const Color(0xffb7c7dc),
            borderRadius: BorderRadius.circular(30),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(_itens.length, (i) {
              final selecionado = i == indiceSelecionado;
              final item = _itens[i];
              return IconButton(
                tooltip: item.$3,
                onPressed: () => aoSelecionar(i),
                icon: Icon(
                  selecionado ? item.$2 : item.$1,
                  color: selecionado ? const Color(0xff063b6d) : const Color(0xff5c7089),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
