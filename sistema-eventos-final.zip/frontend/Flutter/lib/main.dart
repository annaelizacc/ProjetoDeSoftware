import 'package:flutter/material.dart';

import 'pages/app_shell.dart';
import 'pages/login_page.dart';

void main() {
  runApp(const FluxoApp());
}

class FluxoApp extends StatelessWidget {
  const FluxoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fluxo Eventos',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xff0b4b83),
          primary: const Color(0xff063b6d),
          secondary: const Color(0xff55b6f5),
        ),
        scaffoldBackgroundColor: const Color(0xfff2f7fb),
        fontFamily: 'Arial',
      ),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginPage()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xffa3d3f0),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.event_available, size: 92, color: Colors.white),
            SizedBox(height: 14),
            Text(
              'FLUXO',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                letterSpacing: 4,
                fontWeight: FontWeight.w300,
              ),
            ),
            SizedBox(height: 24),
            CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}