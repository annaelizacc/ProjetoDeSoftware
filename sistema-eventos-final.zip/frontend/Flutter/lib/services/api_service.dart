import 'dart:convert';

import 'package:http/http.dart' as http;

/// Centraliza todas as chamadas HTTP.
///
/// A URL pode ser alterada sem editar o código:
/// flutter run --dart-define=API_URL=http://10.0.2.2:5000
class ApiService {
  static const String baseUrl = String.fromEnvironment(
    'API_URL',
    defaultValue: 'http://127.0.0.1:5000',
  );

  static Future<dynamic> request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final headers = {'Content-Type': 'application/json'};
    late http.Response response;

    try {
      if (method == 'POST') {
        response = await http.post(uri, headers: headers, body: jsonEncode(body));
      } else if (method == 'DELETE') {
        response = await http.delete(uri, headers: headers, body: jsonEncode(body));
      } else {
        response = await http.get(uri, headers: headers);
      }
    } catch (_) {
      throw Exception('Servidor indisponível. Verifique a API Flask.');
    }

    dynamic data;
    try {
      data = jsonDecode(response.body);
    } catch (_) {
      data = {};
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data is Map && data['erro'] != null
          ? data['erro'].toString()
          : 'Não foi possível concluir a operação.');
    }
    return data;
  }

  static Future<Map<String, dynamic>> login(String email, String senha) async {
    final data = await request(
      '/api/auth/login',
      method: 'POST',
      body: {'email': email, 'senha': senha},
    );
    return Map<String, dynamic>.from(data['usuario']);
  }

  static Future<List<dynamic>> eventos() async =>
      List<dynamic>.from(await request('/api/eventos'));

  static Future<List<dynamic>> programacao(int eventoId, {String? tema}) async {
    final filtro = tema == null || tema.trim().isEmpty
        ? ''
        : '?tema=${Uri.encodeQueryComponent(tema)}';
    return List<dynamic>.from(
      await request('/api/palestras?id_evento=$eventoId$filtro'),
    );
  }

  static Future<Map<String, dynamic>> palestra(int id, int usuarioId) async =>
      Map<String, dynamic>.from(
        await request('/api/palestras/$id?id_usuario=$usuarioId'),
      );

  static Future<List<dynamic>> agenda(int usuarioId) async =>
      List<dynamic>.from(await request('/api/eventos/$usuarioId/agenda'));

  static Future<List<dynamic>> favoritos(int usuarioId) async =>
      List<dynamic>.from(await request('/api/favoritos/usuario/$usuarioId'));

  static Future<List<dynamic>> notificacoes(int usuarioId) async =>
      List<dynamic>.from(
        await request('/api/notificacoes/usuario/$usuarioId'),
      );

  static Future<void> inscrever(int usuarioId, int palestraId) async {
    await request(
      '/api/inscricoes',
      method: 'POST',
      body: {'id_usuario': usuarioId, 'id_palestra': palestraId},
    );
  }

  static Future<void> cancelarInscricao(int usuarioId, int palestraId) async {
    await request(
      '/api/inscricoes',
      method: 'DELETE',
      body: {'id_usuario': usuarioId, 'id_palestra': palestraId},
    );
  }

  static Future<void> alterarFavorito(
    int usuarioId,
    int palestraId,
    bool adicionar,
  ) async {
    await request(
      '/api/favoritos',
      method: adicionar ? 'POST' : 'DELETE',
      body: {'id_usuario': usuarioId, 'id_palestra': palestraId},
    );
  }

  static Future<void> alterarLembrete(
    int usuarioId,
    int palestraId,
    bool ativar,
  ) async {
    await request(
      '/api/lembretes',
      method: ativar ? 'POST' : 'DELETE',
      body: {'id_usuario': usuarioId, 'id_palestra': palestraId},
    );
  }
}