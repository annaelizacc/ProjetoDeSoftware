import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';
import 'palestra_details_page.dart';

class AgendaPage extends StatelessWidget {
  final int usuarioId;

  const AgendaPage({super.key, required this.usuarioId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Minha agenda')),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.agenda(usuarioId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final lista = snapshot.data ?? [];
          if (lista.isEmpty) return const Center(child: Text('Você ainda não possui inscrições.'));
          return ListView(
            padding: const EdgeInsets.all(16),
            children: lista.map((json) {
              final p = Palestra.fromJson(Map<String, dynamic>.from(json));
              return Card(child: ListTile(title: Text(p.titulo), subtitle: Text('${p.horario} • ${p.sala ?? ''}'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PalestraDetailsPage(usuarioId: usuarioId, palestraId: p.id)))));
            }).toList(),
          );
        },
      ),
    );
  }
}