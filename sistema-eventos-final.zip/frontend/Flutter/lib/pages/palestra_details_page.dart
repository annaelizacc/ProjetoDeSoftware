import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';

class PalestraDetailsPage extends StatefulWidget {
  final int usuarioId;
  final int palestraId;

  const PalestraDetailsPage({super.key, required this.usuarioId, required this.palestraId});

  @override
  State<PalestraDetailsPage> createState() => _PalestraDetailsPageState();
}

class _PalestraDetailsPageState extends State<PalestraDetailsPage> {
  late Future<Palestra> futuro;

  @override
  void initState() {
    super.initState();
    futuro = carregar();
  }

  Future<Palestra> carregar() async => Palestra.fromJson(await ApiService.palestra(widget.palestraId, widget.usuarioId));

  Future<void> executar(Future<void> Function() acao) async {
    try {
      await acao();
      if (mounted) setState(() => futuro = carregar());
    } catch (erro) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(erro.toString().replaceFirst('Exception: ', ''))));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detalhes da palestra')),
      body: FutureBuilder<Palestra>(
        future: futuro,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final p = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(p.titulo, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(0xff063b6d))),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                Chip(label: Text(p.tema ?? 'Sem tema')),
                Chip(label: Text(p.sala ?? 'Sala a definir')),
                Chip(label: Text(p.horario)),
              ]),
              const SizedBox(height: 20),
              Text(p.resumo ?? 'Resumo não informado.', style: const TextStyle(fontSize: 16, height: 1.5)),
              const SizedBox(height: 22),
              Card(
                color: p.vagas > 0 ? const Color(0xffe4f5ff) : const Color(0xffffe9e9),
                child: ListTile(
                  leading: Icon(p.vagas > 0 ? Icons.people_alt_outlined : Icons.block),
                  title: Text(p.vagas > 0 ? '${p.vagas} vagas disponíveis' : 'Palestra lotada'),
                  subtitle: Text('Capacidade total: ${p.total}'),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: p.inscrito
                    ? () => executar(() => ApiService.cancelarInscricao(widget.usuarioId, p.id))
                    : p.vagas > 0
                        ? () => executar(() => ApiService.inscrever(widget.usuarioId, p.id))
                        : null,
                icon: Icon(p.inscrito ? Icons.event_busy : Icons.event_available),
                label: Text(p.inscrito ? 'Cancelar inscrição' : 'Inscrever-se'),
              ),
              OutlinedButton.icon(
                onPressed: () => executar(() => ApiService.alterarFavorito(widget.usuarioId, p.id, !p.favorita)),
                icon: Icon(p.favorita ? Icons.star : Icons.star_border),
                label: Text(p.favorita ? 'Remover dos favoritos' : 'Favoritar palestra'),
              ),
              OutlinedButton.icon(
                onPressed: () => executar(() => ApiService.alterarLembrete(widget.usuarioId, p.id, !p.lembreteAtivo)),
                icon: Icon(p.lembreteAtivo ? Icons.notifications_active : Icons.notifications_none),
                label: Text(p.lembreteAtivo ? 'Desativar lembrete' : 'Ativar lembrete'),
              ),
            ],
          );
        },
      ),
    );
  }
}