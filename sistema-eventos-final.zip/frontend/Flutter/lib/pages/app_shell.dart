import 'package:flutter/material.dart';

import 'agenda_page.dart';
import 'favoritos_page.dart';
import 'home_page.dart';
import 'notificacoes_page.dart';

class AppShell extends StatefulWidget {
  final int usuarioId;
  final String nomeUsuario;

  const AppShell({
    super.key,
    required this.usuarioId,
    required this.nomeUsuario,
  });

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int aba = 0;

  @override
  Widget build(BuildContext context) {
    final telas = [
      HomePage(usuarioId: widget.usuarioId, nomeUsuario: widget.nomeUsuario),
      AgendaPage(usuarioId: widget.usuarioId),
      FavoritosPage(usuarioId: widget.usuarioId),
      NotificacoesPage(usuarioId: widget.usuarioId),
    ];
    return Scaffold(
      body: telas[aba],
      bottomNavigationBar: NavigationBar(
        selectedIndex: aba,
        onDestinationSelected: (index) => setState(() => aba = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Agenda'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'Favoritos'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Avisos'),
        ],
      ),
    );
  }
}