import 'package:flutter/material.dart';

import '../models/palestra.dart';
import '../services/api_service.dart';
import 'palestra_details_page.dart';

class FavoritosPage extends StatefulWidget {
  final int usuarioId;

  const FavoritosPage({super.key, required this.usuarioId});

  @override
  State<FavoritosPage> createState() => _FavoritosPageState();
}

class _FavoritosPageState extends State<FavoritosPage> {
  late Future<List<dynamic>> futuro;

  @override
  void initState() {
    super.initState();
    futuro = ApiService.favoritos(widget.usuarioId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meus favoritos')),
      body: FutureBuilder<List<dynamic>>(
        future: futuro,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final lista = snapshot.data ?? [];
          if (lista.isEmpty) return const Center(child: Text('Nenhuma palestra favoritada.'));
          return ListView(
            padding: const EdgeInsets.all(16),
            children: lista.map((item) {
              final p = Palestra.fromJson(Map<String, dynamic>.from(item['palestra']));
              return Card(child: ListTile(leading: const Icon(Icons.star, color: Colors.amber), title: Text(p.titulo), subtitle: Text(p.tema ?? ''), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PalestraDetailsPage(usuarioId: widget.usuarioId, palestraId: p.id)))));
            }).toList(),
          );
        },
      ),
    );
  }
}