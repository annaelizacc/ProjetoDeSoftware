import 'package:flutter/material.dart';

import '../services/api_service.dart';

class NotificacoesPage extends StatelessWidget {
  final int usuarioId;

  const NotificacoesPage({super.key, required this.usuarioId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Avisos e notificações')),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.notificacoes(usuarioId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text(snapshot.error.toString()));
          final lista = snapshot.data ?? [];
          if (lista.isEmpty) return const Center(child: Text('Você não possui notificações.'));
          return ListView(
            padding: const EdgeInsets.all(16),
            children: lista.map((item) => Card(child: ListTile(leading: const Icon(Icons.notifications_active, color: Color(0xff1689d2)), title: Text(item['mensagem'] ?? ''), subtitle: Text(item['tipo_notificacao'] ?? 'aviso'))).toList(),
          );
        },
      ),
    );
  }
}