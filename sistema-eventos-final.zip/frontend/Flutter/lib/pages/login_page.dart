import 'package:flutter/material.dart';

import '../services/api_service.dart';
import 'app_shell.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(text: 'ana.silva@email.com');
  final senha = TextEditingController(text: 'hash123');
  bool carregando = false;

  Future<void> entrar() async {
    setState(() => carregando = true);
    try {
      final usuario = await ApiService.login(email.text, senha.text);
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => AppShell(
            usuarioId: usuario['id_usuario'],
            nomeUsuario: usuario['nome'],
          ),
        ),
      );
    } catch (erro) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(erro.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffa3d3f0),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              color: const Color(0xff195892).withOpacity(.92),
              elevation: 10,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              child: Padding(
                padding: const EdgeInsets.all(26),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'FLUXO',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 30),
                    const Text('Entrar', style: TextStyle(color: Colors.white, fontSize: 25)),
                    const SizedBox(height: 20),
                    TextField(
                      controller: email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: _decoracao('Email', Icons.email_outlined),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: senha,
                      obscureText: true,
                      decoration: _decoracao('Senha', Icons.lock_outline),
                    ),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: carregando ? null : entrar,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xff062b52),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: carregando
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(color: Colors.white),
                            )
                          : const Text('Entrar'),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Use os dados de Ana Silva do banco oficial.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _decoracao(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
    );
  }

  @override
  void dispose() {
    email.dispose();
    senha.dispose();
    super.dispose();
  }
}