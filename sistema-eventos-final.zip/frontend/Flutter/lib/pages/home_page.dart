import 'package:flutter/material.dart';

import '../services/api_service.dart';
import 'programacao_page.dart';

class HomePage extends StatefulWidget {
  final int usuarioId;
  final String nomeUsuario;

  const HomePage({super.key, required this.usuarioId, required this.nomeUsuario});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<dynamic>> futuroEventos;

  @override
  void initState() {
    super.initState();
    futuroEventos = ApiService.eventos();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () async => setState(() => futuroEventos = ApiService.eventos()),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Olá, ${widget.nomeUsuario}', style: const TextStyle(fontSize: 16, color: Colors.black54)),
            const SizedBox(height: 4),
            const Text('Encontre seu próximo evento', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: Color(0xff063b6d))),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: const Color(0xff55b6f5),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Row(
                children: [
                  Icon(Icons.event_available, color: Colors.white, size: 45),
                  SizedBox(width: 14),
                  Expanded(child: Text('A programação oficial está pronta para você.', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600))),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('Eventos disponíveis', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            FutureBuilder<List<dynamic>>(
              future: futuroEventos,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
                }
                if (snapshot.hasError) return Text('Erro: ${snapshot.error}');
                if (!snapshot.hasData || snapshot.data!.isEmpty) return const Text('Nenhum evento encontrado.');
                return Column(
                  children: snapshot.data!.map((evento) {
                    return Card(
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.event)),
                        title: Text(evento['nome'] ?? ''),
                        subtitle: Text(evento['local'] ?? 'Local não informado'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProgramacaoPage(
                              eventoId: evento['id_evento'],
                              nomeEvento: evento['nome'],
                              usuarioId: widget.usuarioId,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}