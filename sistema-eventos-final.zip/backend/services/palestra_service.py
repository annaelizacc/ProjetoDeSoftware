from datetime import datetime

from backend.models.favorito import Favorito
from backend.models.palestra import Palestra
from backend.models.participacao import Participacao
from backend.models.usuario import Usuario
from backend.models.evento import Evento
from backend.repositories.palestra_repository import PalestraRepository


class PalestraService:
    @staticmethod
    def _data(valor):
        """Converte o texto vindo do Flutter para o tipo DateTime do banco."""
        if not valor:
            return None
        if isinstance(valor, datetime):
            return valor
        return datetime.fromisoformat(str(valor).replace("Z", "+00:00")).replace(
            tzinfo=None
        )

    @staticmethod
    def listar(id_evento=None, tema=None):
        return [
            palestra.to_dict()
            for palestra in PalestraRepository.listar(id_evento, tema)
        ]

    @staticmethod
    def detalhes(id_palestra, id_usuario=None):
        palestra = PalestraRepository.buscar(id_palestra)
        if not palestra:
            raise ValueError("Palestra não encontrada.")

        dados = palestra.to_dict()
        dados["inscrito"] = False
        dados["favorita"] = False
        dados["lembrete_ativo"] = False
        if id_usuario:
            dados["inscrito"] = Participacao.query.filter_by(
                id_usuario=id_usuario, id_palestra=id_palestra
            ).first() is not None
            dados["favorita"] = Favorito.query.filter_by(
                id_usuario=id_usuario, id_palestra=id_palestra
            ).first() is not None
            from backend.repositories.notificacao_repository import NotificacaoRepository

            dados["lembrete_ativo"] = (
                NotificacaoRepository.buscar_lembrete(id_usuario, id_palestra)
                is not None
            )
        return dados

    @staticmethod
    def validar_usuario(id_usuario):
        if not Usuario.query.get(id_usuario):
            raise ValueError("Usuário não encontrado.")

    @staticmethod
    def criar(dados):
        obrigatorios = ("titulo", "id_evento")
        if not all(dados.get(campo) for campo in obrigatorios):
            raise ValueError("titulo e id_evento são obrigatórios.")
        if not Evento.query.get(dados["id_evento"]):
            raise ValueError("Evento não encontrado.")
        palestra = Palestra(
            titulo=dados["titulo"],
            resumo=dados.get("resumo"),
            tema=dados.get("tema"),
            sala=dados.get("sala"),
            horario_inicio=PalestraService._data(dados.get("horario_inicio")),
            horario_fim=PalestraService._data(dados.get("horario_fim")),
            id_evento=dados["id_evento"],
            vagas_total=int(dados.get("vagas_total", 50)),
            vagas_disponiveis=int(dados.get("vagas_total", 50)),
        )
        from backend.extensions import db

        db.session.add(palestra)
        db.session.commit()
        return palestra