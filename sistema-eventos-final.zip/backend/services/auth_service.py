from werkzeug.security import check_password_hash

from backend.models.usuario import Usuario


class AuthService:
    @staticmethod
    def login(email, senha):
        usuario = Usuario.query.filter_by(email=email.strip().lower()).first()
        if not usuario:
            return None

        # O SQL novo usa hashes Werkzeug. O fallback permite que o banco antigo
        # de demonstração continue funcionando até ser migrado.
        try:
            senha_valida = check_password_hash(usuario.senha, senha)
        except ValueError:
            senha_valida = usuario.senha == senha
        return usuario if senha_valida else None