from backend.extensions import db
from backend.models.palestra import Palestra
from backend.models.usuario import Usuario
from backend.repositories.favorito_repository import FavoritoRepository
from backend.models.favorito import Favorito


class FavoritoService:
    @staticmethod
    def listar(id_usuario):
        if not Usuario.query.get(id_usuario):
            raise ValueError("Usuário não encontrado.")
        return [
            {**favorito.to_dict(), "palestra": favorito.palestra.to_dict()}
            for favorito in FavoritoRepository.listar_por_usuario(id_usuario)
        ]

    @staticmethod
    def adicionar(id_usuario, id_palestra):
        if not Usuario.query.get(id_usuario):
            raise ValueError("Usuário não encontrado.")
        if not Palestra.query.get(id_palestra):
            raise ValueError("Palestra não encontrada.")
        if FavoritoRepository.buscar(id_usuario, id_palestra):
            raise ValueError("Palestra já está nos favoritos.")
        favorito = Favorito(id_usuario=id_usuario, id_palestra=id_palestra)
        db.session.add(favorito)
        db.session.commit()
        return favorito

    @staticmethod
    def remover(id_usuario, id_palestra):
        favorito = FavoritoRepository.buscar(id_usuario, id_palestra)
        if not favorito:
            raise ValueError("Favorito não encontrado.")
        db.session.delete(favorito)
        db.session.commit()