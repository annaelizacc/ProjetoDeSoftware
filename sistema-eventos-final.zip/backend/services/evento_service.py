from backend.models.evento import Evento
from backend.repositories.palestra_repository import AgendaRepository


class EventoService:
    @staticmethod
    def listar():
        return [evento.to_dict() for evento in Evento.query.order_by(Evento.data_inicio).all()]

    @staticmethod
    def buscar(id_evento):
        return Evento.query.get(id_evento)

    @staticmethod
    def programacao(id_evento):
        evento = EventoService.buscar(id_evento)
        if not evento:
            raise ValueError("Evento não encontrado.")
        return [p.to_dict() for p in evento.palestras]

    @staticmethod
    def agenda(id_usuario):
        return [p.to_dict() for p in AgendaRepository.listar_por_usuario(id_usuario)]