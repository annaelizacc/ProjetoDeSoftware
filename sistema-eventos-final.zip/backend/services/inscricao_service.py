from backend.extensions import db
from backend.models.palestra import Palestra
from backend.models.participacao import Participacao
from backend.models.usuario import Usuario


class InscricaoService:
    """Caso de uso responsável por inscrições e pelo contador de vagas."""

    @staticmethod
    def criar(id_usuario, id_palestra):
        if not Usuario.query.get(id_usuario):
            raise ValueError("Usuário não encontrado.")

        # O bloqueio da linha evita que duas inscrições simultâneas consumam
        # a mesma vaga. A regra continua no Service, não no Flutter.
        palestra = (
            Palestra.query.with_for_update()
            .filter_by(id_palestra=id_palestra)
            .first()
        )
        if not palestra:
            raise ValueError("Palestra não encontrada.")
        if Participacao.query.filter_by(
            id_usuario=id_usuario, id_palestra=id_palestra
        ).first():
            raise ValueError("Usuário já está inscrito nesta palestra.")
        if palestra.vagas_disponiveis <= 0:
            raise ValueError("Não há vagas disponíveis para esta palestra.")

        inscricao = Participacao(
            id_usuario=id_usuario, id_palestra=id_palestra
        )
        palestra.vagas_disponiveis -= 1
        db.session.add(inscricao)
        db.session.commit()
        return inscricao

    @staticmethod
    def cancelar(id_usuario, id_palestra):
        inscricao = Participacao.query.filter_by(
            id_usuario=id_usuario, id_palestra=id_palestra
        ).first()
        if not inscricao:
            raise ValueError("Inscrição não encontrada.")
        palestra = Palestra.query.with_for_update().get(id_palestra)
        if palestra:
            palestra.vagas_disponiveis = min(
                palestra.vagas_total, palestra.vagas_disponiveis + 1
            )
        db.session.delete(inscricao)
        db.session.commit()

    @staticmethod
    def agenda(id_usuario):
        from backend.services.evento_service import EventoService

        return EventoService.agenda(id_usuario)