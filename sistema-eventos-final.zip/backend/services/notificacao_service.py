from datetime import datetime, timedelta

from backend.extensions import db
from backend.models.notificacao import Notificacao
from backend.models.palestra import Palestra
from backend.models.usuario import Usuario
from backend.repositories.notificacao_repository import NotificacaoRepository


class NotificacaoService:
    """Notificações e lembretes usam a tabela oficial `notificacao`."""

    @staticmethod
    def listar(id_usuario):
        if not Usuario.query.get(id_usuario):
            raise ValueError("Usuário não encontrado.")
        return [n.to_dict() for n in NotificacaoRepository.listar_por_usuario(id_usuario)]

    @staticmethod
    def ativar_lembrete(id_usuario, id_palestra):
        if not Usuario.query.get(id_usuario):
            raise ValueError("Usuário não encontrado.")
        palestra = Palestra.query.get(id_palestra)
        if not palestra:
            raise ValueError("Palestra não encontrada.")
        if NotificacaoRepository.buscar_lembrete(id_usuario, id_palestra):
            raise ValueError("O lembrete já está ativo.")
        horario = (
            palestra.horario_inicio.strftime("%d/%m às %H:%M")
            if palestra.horario_inicio
            else "no horário programado"
        )
        lembrete = Notificacao(
            mensagem=f"Lembrete ativado: {palestra.titulo} começa em {horario}.",
            tipo_notificacao="lembrete",
            id_usuario=id_usuario,
            id_palestra=id_palestra,
        )
        db.session.add(lembrete)
        db.session.commit()
        return lembrete

    @staticmethod
    def desativar_lembrete(id_usuario, id_palestra):
        lembrete = NotificacaoRepository.buscar_lembrete(id_usuario, id_palestra)
        if not lembrete:
            raise ValueError("Lembrete não encontrado.")
        db.session.delete(lembrete)
        db.session.commit()