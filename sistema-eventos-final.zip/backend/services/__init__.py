"""Services concentram as regras de negócio dos casos de uso."""
