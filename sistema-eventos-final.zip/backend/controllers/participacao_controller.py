from flask import Blueprint, jsonify, request

from backend.controllers.utils import tratar_erros
from backend.services.inscricao_service import InscricaoService


class ParticipacaoController:
    """Endpoints de inscrição e cancelamento."""

    @staticmethod
    @tratar_erros
    def criar():
        dados = request.get_json() or {}
        inscricao = InscricaoService.criar(
            dados.get("id_usuario"), dados.get("id_palestra")
        )
        return jsonify(inscricao.to_dict()), 201

    @staticmethod
    @tratar_erros
    def cancelar():
        dados = request.get_json() or {}
        InscricaoService.cancelar(dados.get("id_usuario"), dados.get("id_palestra"))
        return jsonify({"mensagem": "Inscrição cancelada e vaga devolvida."})


participacao_bp = Blueprint("participacoes", __name__, url_prefix="/api/inscricoes")
participacao_bp.add_url_rule("", view_func=ParticipacaoController.criar, methods=["POST"])
participacao_bp.add_url_rule(
    "", view_func=ParticipacaoController.cancelar, methods=["DELETE"]
)