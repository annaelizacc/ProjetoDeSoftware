from flask import Blueprint, jsonify

from backend.controllers.utils import tratar_erros
from backend.services.evento_service import EventoService


class EventoController:
    @staticmethod
    @tratar_erros
    def listar():
        return jsonify(EventoService.listar())

    @staticmethod
    @tratar_erros
    def buscar(id_evento):
        evento = EventoService.buscar(id_evento)
        if not evento:
            return jsonify({"erro": "Evento não encontrado."}), 404
        return jsonify(evento.to_dict())

    @staticmethod
    @tratar_erros
    def programacao(id_evento):
        return jsonify(EventoService.programacao(id_evento))

    @staticmethod
    @tratar_erros
    def agenda(id_usuario):
        return jsonify(EventoService.agenda(id_usuario))


evento_bp = Blueprint("eventos", __name__, url_prefix="/api/eventos")
evento_bp.add_url_rule("", view_func=EventoController.listar, methods=["GET"])
evento_bp.add_url_rule("/<int:id_evento>", view_func=EventoController.buscar, methods=["GET"])
evento_bp.add_url_rule(
    "/<int:id_evento>/programacao",
    view_func=EventoController.programacao,
    methods=["GET"],
)
evento_bp.add_url_rule(
    "/<int:id_usuario>/agenda",
    view_func=EventoController.agenda,
    methods=["GET"],
)