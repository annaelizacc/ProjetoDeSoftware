from flask import Blueprint, jsonify, request

from backend.controllers.utils import tratar_erros
from backend.services.favorito_service import FavoritoService


class FavoritoController:
    @staticmethod
    @tratar_erros
    def listar(id_usuario):
        return jsonify(FavoritoService.listar(id_usuario))

    @staticmethod
    @tratar_erros
    def adicionar():
        dados = request.get_json() or {}
        favorito = FavoritoService.adicionar(
            dados.get("id_usuario"), dados.get("id_palestra")
        )
        return jsonify(favorito.to_dict()), 201

    @staticmethod
    @tratar_erros
    def remover():
        dados = request.get_json() or {}
        FavoritoService.remover(dados.get("id_usuario"), dados.get("id_palestra"))
        return jsonify({"mensagem": "Favorito removido."})


favorito_bp = Blueprint("favoritos", __name__, url_prefix="/api/favoritos")
favorito_bp.add_url_rule(
    "/usuario/<int:id_usuario>",
    view_func=FavoritoController.listar,
    methods=["GET"],
)
favorito_bp.add_url_rule("", view_func=FavoritoController.adicionar, methods=["POST"])
favorito_bp.add_url_rule("", view_func=FavoritoController.remover, methods=["DELETE"])