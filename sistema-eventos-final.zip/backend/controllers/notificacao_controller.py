from flask import Blueprint, jsonify, request

from backend.controllers.utils import tratar_erros
from backend.services.notificacao_service import NotificacaoService


class NotificacaoController:
    @staticmethod
    @tratar_erros
    def listar(id_usuario):
        return jsonify(NotificacaoService.listar(id_usuario))

    @staticmethod
    @tratar_erros
    def ativar():
        dados = request.get_json() or {}
        lembrete = NotificacaoService.ativar_lembrete(
            dados.get("id_usuario"), dados.get("id_palestra")
        )
        return jsonify(lembrete.to_dict()), 201

    @staticmethod
    @tratar_erros
    def desativar():
        dados = request.get_json() or {}
        NotificacaoService.desativar_lembrete(
            dados.get("id_usuario"), dados.get("id_palestra")
        )
        return jsonify({"mensagem": "Lembrete desativado."})


notificacao_bp = Blueprint("notificacoes", __name__, url_prefix="/api")
notificacao_bp.add_url_rule(
    "/notificacoes/usuario/<int:id_usuario>",
    view_func=NotificacaoController.listar,
    methods=["GET"],
)
notificacao_bp.add_url_rule(
    "/lembretes", view_func=NotificacaoController.ativar, methods=["POST"]
)
notificacao_bp.add_url_rule(
    "/lembretes", view_func=NotificacaoController.desativar, methods=["DELETE"]
)