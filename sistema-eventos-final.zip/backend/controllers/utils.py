from functools import wraps

from flask import jsonify


def tratar_erros(func):
    """Transforma erros de regra de negócio em respostas HTTP compreensíveis."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError as erro:
            return jsonify({"erro": str(erro)}), 400
        except Exception:
            # Não expõe detalhes internos da conexão ou do banco ao usuário.
            return jsonify({"erro": "Erro interno no servidor."}), 500

    return wrapper