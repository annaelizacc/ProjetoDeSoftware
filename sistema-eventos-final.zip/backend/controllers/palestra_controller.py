from flask import Blueprint, jsonify, request

from backend.controllers.utils import tratar_erros
from backend.services.palestra_service import PalestraService


class PalestraController:
    @staticmethod
    @tratar_erros
    def listar():
        return jsonify(
            PalestraService.listar(
                request.args.get("id_evento", type=int),
                request.args.get("tema"),
            )
        )

    @staticmethod
    @tratar_erros
    def detalhes(id_palestra):
        return jsonify(
            PalestraService.detalhes(
                id_palestra, request.args.get("id_usuario", type=int)
            )
        )

    @staticmethod
    @tratar_erros
    def criar():
        return jsonify(PalestraService.criar(request.get_json() or {}).to_dict()), 201


palestra_bp = Blueprint("palestras", __name__, url_prefix="/api/palestras")
palestra_bp.add_url_rule("", view_func=PalestraController.listar, methods=["GET"])
palestra_bp.add_url_rule(
    "/<int:id_palestra>", view_func=PalestraController.detalhes, methods=["GET"]
)
palestra_bp.add_url_rule("", view_func=PalestraController.criar, methods=["POST"])