from backend.controllers.auth_controller import auth_bp
from backend.controllers.evento_controller import evento_bp
from backend.controllers.favorito_controller import favorito_bp
from backend.controllers.notificacao_controller import notificacao_bp
from backend.controllers.palestra_controller import palestra_bp
from backend.controllers.participacao_controller import participacao_bp


def registrar_rotas(app):
    """Ponto único para registrar os Blueprints da aplicação."""

    for blueprint in (
        auth_bp,
        evento_bp,
        palestra_bp,
        participacao_bp,
        favorito_bp,
        notificacao_bp,
    ):
        app.register_blueprint(blueprint)