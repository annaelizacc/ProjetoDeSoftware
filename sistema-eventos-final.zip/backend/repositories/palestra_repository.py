from sqlalchemy import or_

from backend.models.palestra import Palestra
from backend.models.participacao import Participacao


class PalestraRepository:
    """Consultas que combinam filtros e ordenação das palestras."""

    @staticmethod
    def listar(id_evento=None, tema=None):
        consulta = Palestra.query
        if id_evento:
            consulta = consulta.filter(Palestra.id_evento == id_evento)
        if tema:
            termo = f"%{tema.strip()}%"
            consulta = consulta.filter(
                or_(Palestra.tema.ilike(termo), Palestra.titulo.ilike(termo))
            )
        return consulta.order_by(Palestra.horario_inicio.asc()).all()

    @staticmethod
    def buscar(id_palestra):
        return Palestra.query.get(id_palestra)


class AgendaRepository:
    """Consulta específica da agenda: participações + palestras + eventos."""

    @staticmethod
    def listar_por_usuario(id_usuario):
        return (
            Palestra.query.join(
                Participacao,
                Palestra.id_palestra == Participacao.id_palestra,
            )
            .filter(Participacao.id_usuario == id_usuario)
            .order_by(Palestra.horario_inicio.asc())
            .all()
        )