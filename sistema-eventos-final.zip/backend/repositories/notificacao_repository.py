from backend.models.notificacao import Notificacao


class NotificacaoRepository:
    @staticmethod
    def listar_por_usuario(id_usuario):
        return (
            Notificacao.query.filter_by(id_usuario=id_usuario)
            .order_by(Notificacao.data_envio.desc())
            .all()
        )

    @staticmethod
    def buscar_lembrete(id_usuario, id_palestra):
        return Notificacao.query.filter_by(
            id_usuario=id_usuario,
            id_palestra=id_palestra,
            tipo_notificacao="lembrete",
        ).first()