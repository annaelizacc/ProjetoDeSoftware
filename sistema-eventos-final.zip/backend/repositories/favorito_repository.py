from sqlalchemy.orm import joinedload

from backend.models.favorito import Favorito


class FavoritoRepository:
    @staticmethod
    def buscar(id_usuario, id_palestra):
        return Favorito.query.filter_by(
            id_usuario=id_usuario, id_palestra=id_palestra
        ).first()

    @staticmethod
    def listar_por_usuario(id_usuario):
        return (
            Favorito.query.options(joinedload(Favorito.palestra))
            .filter_by(id_usuario=id_usuario)
            .all()
        )