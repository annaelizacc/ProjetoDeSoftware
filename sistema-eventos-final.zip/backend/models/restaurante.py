from backend.extensions import db


class Restaurante(db.Model):
    __tablename__ = "restaurante"

    id_restaurante = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    avaliacao = db.Column(db.Numeric(2, 1))
    distancia = db.Column(db.Numeric(6, 2))
    categoria = db.Column(db.String(80))
    endereco = db.Column(db.String(200))