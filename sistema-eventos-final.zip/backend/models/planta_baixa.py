from backend.extensions import db


class PlantaBaixa(db.Model):
    __tablename__ = "planta_baixa"

    id_planta = db.Column(db.Integer, primary_key=True)
    imagem_mapa = db.Column(db.String(255))
    descricao = db.Column(db.Text)
    id_evento = db.Column(db.Integer, db.ForeignKey("evento.id_evento"), nullable=False)