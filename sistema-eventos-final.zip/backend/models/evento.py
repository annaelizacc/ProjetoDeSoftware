from backend.extensions import db


class Evento(db.Model):
    """Evento que reúne uma ou mais palestras."""

    __tablename__ = "evento"

    id_evento = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    descricao = db.Column(db.Text)
    data_inicio = db.Column(db.Date, nullable=False)
    data_fim = db.Column(db.Date, nullable=False)
    local = db.Column(db.String(200))

    palestras = db.relationship(
        "Palestra", back_populates="evento", cascade="all, delete-orphan"
    )

    def to_dict(self):
        return {
            "id_evento": self.id_evento,
            "nome": self.nome,
            "descricao": self.descricao,
            "data_inicio": self.data_inicio.isoformat() if self.data_inicio else None,
            "data_fim": self.data_fim.isoformat() if self.data_fim else None,
            "local": self.local,
        }