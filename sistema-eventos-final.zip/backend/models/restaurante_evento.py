from backend.extensions import db


class RestauranteEvento(db.Model):
    __tablename__ = "restaurante_evento"

    id_restaurante = db.Column(
        db.Integer, db.ForeignKey("restaurante.id_restaurante"), primary_key=True
    )
    id_evento = db.Column(
        db.Integer, db.ForeignKey("evento.id_evento"), primary_key=True
    )